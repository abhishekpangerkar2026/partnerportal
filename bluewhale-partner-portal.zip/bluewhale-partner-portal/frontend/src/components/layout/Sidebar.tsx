'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useUser } from '@auth0/nextjs-auth0/client'
import {
  LayoutDashboard, FileText, Tag, Briefcase, BookOpen,
  Bell, Settings, LogOut, ChevronDown, Building2,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const partnerNav = [
  { label: 'Dashboard',        href: '/portal/dashboard',      icon: LayoutDashboard },
  { label: 'Deal Registration',href: '/portal/deals',          icon: FileText },
  { label: 'Discounts',        href: '/portal/discounts',      icon: Tag },
  { label: 'Co-sell Workspace',href: '/portal/workspace',      icon: Briefcase },
  { label: 'Training',         href: '/portal/training',       icon: BookOpen },
  { label: 'Notifications',    href: '/portal/notifications',  icon: Bell },
  { label: 'Settings',         href: '/portal/settings',       icon: Settings },
]

const internalNav = [
  { label: 'Dashboard',        href: '/internal/dashboard',    icon: LayoutDashboard },
  { label: 'Partners',         href: '/internal/partners',     icon: Building2 },
  { label: 'Deal Queue',       href: '/internal/deals',        icon: FileText },
  { label: 'Discounts',        href: '/internal/discounts',    icon: Tag },
  { label: 'Workspaces',       href: '/internal/workspace',    icon: Briefcase },
  { label: 'Notifications',    href: '/internal/notifications',icon: Bell },
  { label: 'Settings',         href: '/internal/settings',     icon: Settings },
]

interface SidebarProps {
  variant?: 'partner' | 'internal'
}

export function Sidebar({ variant = 'partner' }: SidebarProps) {
  const pathname = usePathname()
  const { user } = useUser()
  const nav = variant === 'partner' ? partnerNav : internalNav

  return (
    <aside className="flex h-screen w-64 flex-col border-r bg-white dark:bg-gray-950">
      {/* Logo */}
      <div className="flex h-16 items-center gap-2 border-b px-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-700">
          <span className="text-xs font-bold text-white">BW</span>
        </div>
        <div>
          <p className="text-sm font-semibold text-brand-700">BlueWhale Stack</p>
          <p className="text-[10px] text-muted-foreground">Partner Portal</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <div className="space-y-1">
          {nav.map((item) => {
            const Icon = item.icon
            const active = pathname === item.href || pathname.startsWith(item.href + '/')
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'nav-item',
                  active && 'active'
                )}
              >
                <Icon className="h-4 w-4 flex-shrink-0" />
                {item.label}
              </Link>
            )
          })}
        </div>
      </nav>

      {/* User footer */}
      <div className="border-t p-3">
        <div className="flex items-center gap-3 rounded-lg px-2 py-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
            {user?.name?.charAt(0).toUpperCase() ?? 'U'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-medium">{user?.name ?? 'Partner User'}</p>
            <p className="truncate text-[10px] text-muted-foreground">{user?.email ?? ''}</p>
          </div>
          <a href="/api/auth/logout" className="text-muted-foreground hover:text-red-500">
            <LogOut className="h-4 w-4" />
          </a>
        </div>
      </div>
    </aside>
  )
}
