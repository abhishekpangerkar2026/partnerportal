'use client'

import { useState }  from 'react'
import { useForm }   from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z }         from 'zod'
import { useRouter } from 'next/navigation'
import axios         from 'axios'

const steps = ['Company', 'Contact', 'Partnership', 'Agreement']

const schema = z.object({
  companyName:        z.string().min(2),
  tradingName:        z.string().optional(),
  registrationNumber: z.string().min(1),
  countryCode:        z.string().length(2),
  website:            z.string().url(),
  industry:           z.string().min(1),
  contactName:        z.string().min(2),
  contactEmail:       z.string().email(),
  contactPhone:       z.string().min(7),
  partnershipTypes:   z.array(z.string()).min(1),
  productsOfInterest: z.array(z.string()).min(1),
  annualRevenueRange: z.string().min(1),
  agreeTerms:         z.literal(true, { errorMap: () => ({ message: 'You must accept the agreement' }) }),
  agreeContact:       z.literal(true, { errorMap: () => ({ message: 'Required' }) }),
})

type FormData = z.infer<typeof schema>

const PARTNERSHIP_TYPES = ['Reseller', 'Referral', 'Co-sell', 'Technology', 'MSP']
const PRODUCTS          = ['BW Cloud Platform', 'BW Data Suite', 'BW Security Hub', 'BW Analytics Pro', 'BW AI Services']
const INDUSTRIES        = ['Technology', 'Healthcare', 'Finance', 'Retail', 'Manufacturing', 'Education', 'Government', 'Other']
const REVENUE_RANGES    = ['< $1M', '$1M – $10M', '$10M – $50M', '$50M – $250M', '> $250M']

export default function RegisterPage() {
  const router       = useRouter()
  const [step, setStep]         = useState(0)
  const [submitted, setSubmitted] = useState(false)

  const { register, handleSubmit, watch, setValue, trigger, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { partnershipTypes: [], productsOfInterest: [] },
  })

  const selectedTypes    = watch('partnershipTypes') ?? []
  const selectedProducts = watch('productsOfInterest') ?? []

  function toggleArr(field: 'partnershipTypes' | 'productsOfInterest', val: string) {
    const cur  = watch(field) ?? []
    const next = cur.includes(val) ? cur.filter((x: string) => x !== val) : [...cur, val]
    setValue(field, next)
  }

  async function nextStep() {
    const fieldsPerStep: (keyof FormData)[][] = [
      ['companyName', 'registrationNumber', 'countryCode', 'website', 'industry'],
      ['contactName', 'contactEmail', 'contactPhone'],
      ['partnershipTypes', 'productsOfInterest', 'annualRevenueRange'],
      ['agreeTerms', 'agreeContact'],
    ]
    const valid = await trigger(fieldsPerStep[step])
    if (valid) setStep(s => s + 1)
  }

  async function onSubmit(data: FormData) {
    try {
      await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/partners/register`,
        data
      )
      setSubmitted(true)
    } catch {
      alert('Registration failed — please try again')
    }
  }

  if (submitted) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="max-w-md rounded-2xl bg-white p-10 text-center shadow-sm border">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100">
            <span className="text-2xl">✓</span>
          </div>
          <h2 className="text-xl font-semibold text-gray-900">Registration Submitted!</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Your application is under review. You'll receive a response within 3 business days.
          </p>
          <p className="mt-4 text-xs text-muted-foreground">
            Have an account already?{' '}
            <a href="/api/auth/login" className="text-brand-700 underline">Sign in</a>
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Left brand panel */}
      <div className="hidden lg:flex lg:w-96 flex-col bg-brand-700 p-10 text-white">
        <div className="flex items-center gap-2.5 mb-12">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/20 font-bold text-sm">BW</div>
          <div>
            <p className="font-semibold">BlueWhale Stack</p>
            <p className="text-xs text-white/60">Partner Network</p>
          </div>
        </div>
        <div className="flex-1 space-y-8">
          {[
            { emoji: '🛡️', title: 'Deal Protection',    desc: 'Register deals to prevent channel conflict and protect your pipeline.' },
            { emoji: '💰', title: 'Partner Discounts',  desc: 'Access exclusive partner pricing based on your tier.' },
            { emoji: '🤝', title: 'Co-sell Support',    desc: 'Work directly with our sales team to close faster.' },
            { emoji: '📈', title: 'Tier Benefits',      desc: 'Grow from Registered to Platinum and unlock higher margins.' },
          ].map(b => (
            <div key={b.title} className="flex items-start gap-3">
              <span className="text-xl">{b.emoji}</span>
              <div>
                <p className="font-semibold text-sm">{b.title}</p>
                <p className="text-xs text-white/70 leading-relaxed">{b.desc}</p>
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-white/40">© {new Date().getFullYear()} BlueWhale Stack</p>
      </div>

      {/* Right form panel */}
      <div className="flex flex-1 flex-col items-center justify-center p-8">
        <div className="w-full max-w-lg">
          {/* Step indicator */}
          <div className="mb-8 flex items-center gap-2">
            {steps.map((s, i) => (
              <div key={s} className="flex items-center gap-2">
                <div className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold transition-colors ${
                  i < step ? 'bg-emerald-500 text-white'
                  : i === step ? 'bg-brand-700 text-white'
                  : 'bg-gray-200 text-gray-500'
                }`}>
                  {i < step ? '✓' : i + 1}
                </div>
                <span className={`text-xs ${i === step ? 'font-semibold text-gray-900' : 'text-muted-foreground'}`}>{s}</span>
                {i < steps.length - 1 && <div className="h-px w-6 bg-gray-200" />}
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit(onSubmit)}>

            {/* Step 0 — Company */}
            {step === 0 && (
              <div className="space-y-4">
                <h1 className="text-xl font-semibold">Company Information</h1>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <label className="label">Legal Company Name *</label>
                    <input {...register('companyName')} className="input" placeholder="Acme Ltd" />
                    {errors.companyName && <p className="error">{errors.companyName.message}</p>}
                  </div>
                  <div>
                    <label className="label">Trading / Brand Name</label>
                    <input {...register('tradingName')} className="input" placeholder="Optional" />
                  </div>
                  <div>
                    <label className="label">Registration Number *</label>
                    <input {...register('registrationNumber')} className="input" placeholder="12345678" />
                    {errors.registrationNumber && <p className="error">{errors.registrationNumber.message}</p>}
                  </div>
                  <div>
                    <label className="label">Country Code *</label>
                    <input {...register('countryCode')} className="input" maxLength={2} placeholder="US" />
                    {errors.countryCode && <p className="error">{errors.countryCode.message}</p>}
                  </div>
                  <div>
                    <label className="label">Website *</label>
                    <input {...register('website')} className="input" type="url" placeholder="https://company.com" />
                    {errors.website && <p className="error">{errors.website.message}</p>}
                  </div>
                  <div className="sm:col-span-2">
                    <label className="label">Industry *</label>
                    <select {...register('industry')} className="input">
                      <option value="">Select industry</option>
                      {INDUSTRIES.map(i => <option key={i} value={i}>{i}</option>)}
                    </select>
                    {errors.industry && <p className="error">{errors.industry.message}</p>}
                  </div>
                </div>
              </div>
            )}

            {/* Step 1 — Contact */}
            {step === 1 && (
              <div className="space-y-4">
                <h1 className="text-xl font-semibold">Primary Contact</h1>
                <div>
                  <label className="label">Full Name *</label>
                  <input {...register('contactName')} className="input" placeholder="Jane Smith" />
                  {errors.contactName && <p className="error">{errors.contactName.message}</p>}
                </div>
                <div>
                  <label className="label">Business Email *</label>
                  <input {...register('contactEmail')} className="input" type="email" placeholder="jane@company.com" />
                  {errors.contactEmail && <p className="error">{errors.contactEmail.message}</p>}
                </div>
                <div>
                  <label className="label">Phone Number *</label>
                  <input {...register('contactPhone')} className="input" placeholder="+1 415 555 0100" />
                  {errors.contactPhone && <p className="error">{errors.contactPhone.message}</p>}
                </div>
              </div>
            )}

            {/* Step 2 — Partnership */}
            {step === 2 && (
              <div className="space-y-4">
                <h1 className="text-xl font-semibold">Partnership Interest</h1>
                <div>
                  <label className="label">Partnership Types *</label>
                  <div className="flex flex-wrap gap-2">
                    {PARTNERSHIP_TYPES.map(t => (
                      <button key={t} type="button"
                        onClick={() => toggleArr('partnershipTypes', t)}
                        className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                          selectedTypes.includes(t)
                            ? 'border-brand-700 bg-brand-700 text-white'
                            : 'border-gray-200 text-gray-600 hover:border-brand-300'
                        }`}
                      >{t}</button>
                    ))}
                  </div>
                  {errors.partnershipTypes && <p className="error">{errors.partnershipTypes.message}</p>}
                </div>
                <div>
                  <label className="label">Products of Interest *</label>
                  <div className="flex flex-wrap gap-2">
                    {PRODUCTS.map(p => (
                      <button key={p} type="button"
                        onClick={() => toggleArr('productsOfInterest', p)}
                        className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                          selectedProducts.includes(p)
                            ? 'border-brand-700 bg-brand-700 text-white'
                            : 'border-gray-200 text-gray-600 hover:border-brand-300'
                        }`}
                      >{p}</button>
                    ))}
                  </div>
                  {errors.productsOfInterest && <p className="error">{errors.productsOfInterest.message}</p>}
                </div>
                <div>
                  <label className="label">Annual Revenue Range *</label>
                  <select {...register('annualRevenueRange')} className="input">
                    <option value="">Select range</option>
                    {REVENUE_RANGES.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                  {errors.annualRevenueRange && <p className="error">{errors.annualRevenueRange.message}</p>}
                </div>
              </div>
            )}

            {/* Step 3 — Agreement */}
            {step === 3 && (
              <div className="space-y-4">
                <h1 className="text-xl font-semibold">Partner Agreement</h1>
                <div className="h-48 overflow-y-auto rounded-lg border bg-gray-50 p-4 text-xs text-muted-foreground leading-relaxed">
                  <p className="font-semibold text-gray-900 mb-2">BlueWhale Stack Partner Agreement — Summary</p>
                  <p>By joining the BlueWhale Stack Partner Network, you agree to represent BlueWhale Stack products and services professionally, protect confidential information, comply with deal registration policies, adhere to approved discount structures, and participate in quarterly business reviews as required by your tier.</p>
                  <p className="mt-3">Partners may register deals for prospect companies and receive deal protection for 90 days from registration. Discounts are subject to tier-based ceilings. Revenue thresholds are reviewed annually.</p>
                  <p className="mt-3">BlueWhale Stack reserves the right to modify partner tier requirements, discount structures, and program terms with 30 days notice.</p>
                </div>
                <label className="flex items-start gap-2 cursor-pointer">
                  <input {...register('agreeTerms')} type="checkbox" className="mt-0.5 rounded" />
                  <span className="text-xs text-gray-700">
                    I have read and agree to the BlueWhale Stack Partner Agreement *
                  </span>
                </label>
                {errors.agreeTerms && <p className="error">{errors.agreeTerms.message}</p>}
                <label className="flex items-start gap-2 cursor-pointer">
                  <input {...register('agreeContact')} type="checkbox" className="mt-0.5 rounded" />
                  <span className="text-xs text-gray-700">
                    I consent to BlueWhale Stack contacting me regarding partnership opportunities *
                  </span>
                </label>
                {errors.agreeContact && <p className="error">{errors.agreeContact.message}</p>}
              </div>
            )}

            {/* Navigation */}
            <div className="mt-8 flex justify-between">
              {step > 0
                ? <button type="button" onClick={() => setStep(s => s - 1)} className="btn-secondary">Back</button>
                : <div />
              }
              {step < steps.length - 1
                ? <button type="button" onClick={nextStep} className="btn-primary">Continue →</button>
                : <button type="submit" className="btn-primary">Submit Application</button>
              }
            </div>
          </form>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            Already a partner?{' '}
            <a href="/api/auth/login" className="text-brand-700 underline">Sign in</a>
          </p>
        </div>
      </div>
    </div>
  )
}
