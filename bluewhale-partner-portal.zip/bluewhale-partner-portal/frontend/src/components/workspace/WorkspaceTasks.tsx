'use client'

import { useState }            from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { api }                 from '@/lib/api'
import { format }              from 'date-fns'
import { Plus, CheckCircle2, Circle, AlertCircle, Clock } from 'lucide-react'
import type { WorkspaceTask }  from '@/types'

interface Props {
  dealId:       string
  initialTasks: WorkspaceTask[]
}

const STATUS_CONFIG = {
  open:        { label: 'Open',        icon: Circle,        color: 'text-gray-400' },
  in_progress: { label: 'In Progress', icon: Clock,         color: 'text-blue-500' },
  blocked:     { label: 'Blocked',     icon: AlertCircle,   color: 'text-red-500' },
  completed:   { label: 'Completed',   icon: CheckCircle2,  color: 'text-emerald-500' },
}

const PRIORITY_COLOR = {
  low:    'bg-gray-100 text-gray-600',
  medium: 'bg-amber-100 text-amber-700',
  high:   'bg-red-100 text-red-700',
}

export function WorkspaceTasks({ dealId, initialTasks }: Props) {
  const queryClient = useQueryClient()
  const [tasks, setTasks]         = useState<WorkspaceTask[]>(initialTasks)
  const [showForm, setShowForm]   = useState(false)
  const [newTitle, setNewTitle]   = useState('')
  const [newDue, setNewDue]       = useState('')
  const [newPriority, setNewPriority] = useState<'LOW'|'MEDIUM'|'HIGH'>('MEDIUM')

  const updateMutation = useMutation({
    mutationFn: ({ taskId, status }: { taskId: string; status: string }) =>
      api.patch(`/workspace/${dealId}/tasks/${taskId}`, { status }).then(r => r.data),
    onSuccess: (updated) => {
      setTasks(prev => prev.map(t => t.id === updated.id ? updated : t))
    },
  })

  const createMutation = useMutation({
    mutationFn: () =>
      api.post(`/workspace/${dealId}/tasks`, {
        title:      newTitle,
        assigneeId: '', // TODO: assignee picker
        dueDate:    newDue,
        priority:   newPriority,
      }).then(r => r.data),
    onSuccess: (task) => {
      setTasks(prev => [task, ...prev])
      setShowForm(false)
      setNewTitle('')
      setNewDue('')
    },
  })

  function cycleStatus(task: WorkspaceTask) {
    const order = ['OPEN', 'IN_PROGRESS', 'BLOCKED', 'COMPLETED']
    const next  = order[(order.indexOf(task.status.toUpperCase()) + 1) % order.length]
    updateMutation.mutate({ taskId: task.id, status: next })
  }

  const open      = tasks.filter(t => t.status === 'open' || t.status === 'OPEN')
  const active    = tasks.filter(t => t.status === 'in_progress' || t.status === 'IN_PROGRESS')
  const blocked   = tasks.filter(t => t.status === 'blocked' || t.status === 'BLOCKED')
  const completed = tasks.filter(t => t.status === 'completed' || t.status === 'COMPLETED')

  const groups = [
    { label: 'Open',        items: open },
    { label: 'In Progress', items: active },
    { label: 'Blocked',     items: blocked },
    { label: 'Completed',   items: completed },
  ]

  return (
    <div className="stat-card flex flex-col" style={{ height: '480px' }}>
      <div className="flex items-center justify-between mb-3 border-b pb-2">
        <h3 className="text-sm font-semibold">Tasks</h3>
        <button
          onClick={() => setShowForm(s => !s)}
          className="flex items-center gap-1 text-xs text-brand-700 hover:underline"
        >
          <Plus className="h-3 w-3" /> Add task
        </button>
      </div>

      {/* Quick add form */}
      {showForm && (
        <div className="mb-3 space-y-2 rounded-lg border bg-gray-50 p-3 dark:bg-gray-900">
          <input
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
            placeholder="Task title"
            className="w-full rounded border px-2 py-1.5 text-xs outline-none focus:border-brand-500 bg-white dark:bg-gray-800"
          />
          <div className="flex gap-2">
            <input
              type="date"
              value={newDue}
              onChange={e => setNewDue(e.target.value)}
              className="flex-1 rounded border px-2 py-1.5 text-xs outline-none bg-white dark:bg-gray-800"
            />
            <select
              value={newPriority}
              onChange={e => setNewPriority(e.target.value as 'LOW'|'MEDIUM'|'HIGH')}
              className="rounded border px-2 py-1.5 text-xs outline-none bg-white dark:bg-gray-800"
            >
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
            </select>
          </div>
          <div className="flex gap-2 justify-end">
            <button
              onClick={() => setShowForm(false)}
              className="px-2 py-1 text-xs text-muted-foreground hover:text-gray-700"
            >
              Cancel
            </button>
            <button
              onClick={() => createMutation.mutate()}
              disabled={!newTitle.trim() || !newDue || createMutation.isPending}
              className="rounded bg-brand-700 px-3 py-1 text-xs text-white hover:bg-brand-800 disabled:opacity-40"
            >
              Create
            </button>
          </div>
        </div>
      )}

      {/* Task list */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-1">
        {groups.map(group => group.items.length > 0 && (
          <div key={group.label}>
            <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {group.label} · {group.items.length}
            </p>
            <div className="space-y-1.5">
              {group.items.map(task => {
                const statusKey = task.status.toLowerCase() as keyof typeof STATUS_CONFIG
                const cfg       = STATUS_CONFIG[statusKey] ?? STATUS_CONFIG.open
                const StatusIcon = cfg.icon

                return (
                  <div
                    key={task.id}
                    className={`flex items-start gap-2.5 rounded-lg border p-2.5 hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors ${
                      statusKey === 'completed' ? 'opacity-60' : ''
                    }`}
                  >
                    <button
                      onClick={() => cycleStatus(task)}
                      className={`mt-0.5 flex-shrink-0 ${cfg.color}`}
                      title="Click to advance status"
                    >
                      <StatusIcon className="h-4 w-4" />
                    </button>
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs font-medium ${statusKey === 'completed' ? 'line-through text-muted-foreground' : ''}`}>
                        {task.title}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        {task.dueDate && (
                          <span className="text-[10px] text-muted-foreground">
                            Due {format(new Date(task.dueDate), 'MMM d')}
                          </span>
                        )}
                        <span className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${PRIORITY_COLOR[task.priority as keyof typeof PRIORITY_COLOR] ?? PRIORITY_COLOR.medium}`}>
                          {task.priority}
                        </span>
                      </div>
                    </div>
                    {task.assignee && (
                      <div className="flex-shrink-0 flex h-5 w-5 items-center justify-center rounded-full bg-brand-100 text-[8px] font-bold text-brand-700">
                        {task.assignee.name.charAt(0)}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        ))}
        {tasks.length === 0 && (
          <p className="text-xs text-center text-muted-foreground py-8">
            No tasks yet. Add one to get started.
          </p>
        )}
      </div>
    </div>
  )
}
