import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import type { DealStatus, PartnerTier, DiscountStatus } from '@/types'

// ── Tailwind class merger ────────────────────────────────────────────────────
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ── Currency ─────────────────────────────────────────────────────────────────
export function formatCurrency(value: number, currency = 'USD') {
  return new Intl.NumberFormat('en-US', {
    style: 'currency', currency, maximumFractionDigits: 0,
  }).format(value)
}

// ── Deal status labels & colours ─────────────────────────────────────────────
export const DEAL_STATUS_LABEL: Record<DealStatus, string> = {
  submitted:    'Submitted',
  under_review: 'Under Review',
  accepted:     'Accepted',
  rejected:     'Rejected',
  in_progress:  'In Progress',
  won:          'Won',
  lost:         'Lost',
  expired:      'Expired',
}

export const DEAL_STATUS_CLASS: Record<DealStatus, string> = {
  submitted:    'badge-submitted',
  under_review: 'badge-review',
  accepted:     'badge-accepted',
  rejected:     'badge-rejected',
  in_progress:  'badge-in-progress',
  won:          'badge-won',
  lost:         'badge-lost',
  expired:      'badge-expired',
}

// ── Tier labels ───────────────────────────────────────────────────────────────
export const TIER_LABEL: Record<PartnerTier, string> = {
  registered: 'Registered',
  silver:     'Silver',
  gold:       'Gold',
  platinum:   'Platinum',
}

export const TIER_CLASS: Record<PartnerTier, string> = {
  registered: 'tier-registered',
  silver:     'tier-silver',
  gold:       'tier-gold',
  platinum:   'tier-platinum',
}

// ── Discount status ───────────────────────────────────────────────────────────
export const DISCOUNT_STATUS_LABEL: Record<DiscountStatus, string> = {
  pending:        'Pending',
  approved:       'Approved',
  rejected:       'Rejected',
  counter_offered:'Counter Offered',
}

// ── Misc ──────────────────────────────────────────────────────────────────────
export function truncate(str: string, n: number) {
  return str.length > n ? str.slice(0, n - 1) + '…' : str
}

export function initials(name: string) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
}
