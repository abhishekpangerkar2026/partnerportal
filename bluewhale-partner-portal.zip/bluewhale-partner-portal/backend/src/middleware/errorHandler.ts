import type { FastifyError, FastifyRequest, FastifyReply } from 'fastify'

export function errorHandler(
  error: FastifyError,
  _req: FastifyRequest,
  reply: FastifyReply,
) {
  const statusCode = error.statusCode ?? 500

  if (statusCode >= 500) {
    reply.log.error(error)
  }

  // Zod / validation error from Fastify schema
  if (error.validation) {
    return reply.code(400).send({
      statusCode: 400,
      error:      'Bad Request',
      message:    'Validation failed',
      details:    error.validation,
    })
  }

  return reply.code(statusCode).send({
    statusCode,
    error:   error.name ?? 'Internal Server Error',
    message: statusCode < 500 ? error.message : 'An unexpected error occurred',
  })
}
