'use client'

import { useState }           from 'react'
import { useDropzone }        from 'react-dropzone'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { api }                from '@/lib/api'
import { format }             from 'date-fns'
import { Upload, FileText, Trash2, Download } from 'lucide-react'
import type { DealAttachment } from '@/types'

interface Props {
  dealId:      string
  attachments: DealAttachment[]
}

const FILE_ICONS: Record<string, string> = {
  'application/pdf':                                                                  '📄',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document':         '📝',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation':       '📊',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':               '📈',
}

export function DealAttachments({ dealId, attachments: initial }: Props) {
  const queryClient        = useQueryClient()
  const [files, setFiles]  = useState<DealAttachment[]>(initial)
  const [uploading, setUploading] = useState(false)
  const [error, setError]  = useState<string | null>(null)

  const deleteMutation = useMutation({
    mutationFn: (fileId: string) =>
      api.delete(`/deals/${dealId}/attachments/${fileId}`),
    onSuccess: (_, fileId) => setFiles(prev => prev.filter(f => f.id !== fileId)),
  })

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    maxFiles: 5,
    maxSize:  25 * 1024 * 1024, // 25 MB
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
    },
    onDropAccepted: async (accepted) => {
      setUploading(true)
      setError(null)
      try {
        for (const file of accepted) {
          const formData = new FormData()
          formData.append('file', file)
          const res = await api.post(`/deals/${dealId}/attachments`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
          })
          setFiles(prev => [...prev, res.data])
        }
      } catch {
        setError('Upload failed — please try again')
      } finally {
        setUploading(false)
      }
    },
    onDropRejected: (rejected) => {
      const reason = rejected[0]?.errors[0]?.message ?? 'File rejected'
      setError(reason)
    },
  })

  return (
    <div className="stat-card space-y-4">
      <h2 className="text-sm font-semibold border-b pb-2">Supporting Documents</h2>

      {/* Dropzone */}
      <div
        {...getRootProps()}
        className={`rounded-lg border-2 border-dashed p-5 text-center cursor-pointer transition-colors ${
          isDragActive
            ? 'border-brand-400 bg-brand-50'
            : 'border-gray-200 hover:border-brand-300 hover:bg-gray-50'
        }`}
      >
        <input {...getInputProps()} />
        <Upload className={`mx-auto mb-2 h-6 w-6 ${isDragActive ? 'text-brand-600' : 'text-muted-foreground'}`} />
        <p className="text-xs text-muted-foreground">
          {isDragActive
            ? 'Drop files here…'
            : 'Drag & drop files, or click to browse'
          }
        </p>
        <p className="text-[10px] text-muted-foreground mt-1">PDF, DOCX, PPTX, XLSX · Max 25 MB each</p>
        {uploading && <p className="text-xs text-brand-600 mt-2 animate-pulse">Uploading…</p>}
      </div>

      {error && (
        <p className="text-xs text-red-600 bg-red-50 rounded p-2">{error}</p>
      )}

      {/* File list */}
      {files.length > 0 ? (
        <div className="space-y-2">
          {files.map(file => (
            <div
              key={file.id}
              className="flex items-center gap-3 rounded-lg border bg-gray-50 px-3 py-2.5 dark:bg-gray-900"
            >
              <span className="text-lg">{FILE_ICONS[file.fileType] ?? '📎'}</span>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">{file.fileName}</p>
                <p className="text-[10px] text-muted-foreground">
                  Uploaded {format(new Date(file.uploadedAt), 'MMM d, yyyy')}
                </p>
              </div>
              <div className="flex gap-1.5 flex-shrink-0">
                <a
                  href={file.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded p-1.5 text-muted-foreground hover:bg-gray-200 dark:hover:bg-gray-700"
                  title="Download"
                >
                  <Download className="h-3.5 w-3.5" />
                </a>
                <button
                  onClick={() => deleteMutation.mutate(file.id)}
                  className="rounded p-1.5 text-red-400 hover:bg-red-50"
                  title="Delete"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-xs text-center text-muted-foreground py-2">
          No documents uploaded yet.
        </p>
      )}
    </div>
  )
}
