import type { FastifyInstance } from 'fastify'
import { z } from 'zod'
import { prisma }          from '../config/db'
import { authenticate, requireRoles } from '../middleware/auth'
import { DealService }     from '../services/DealService'
import { NotificationService } from '../services/NotificationService'
import type { DealStatus } from '@prisma/client'

const createDealSchema = z.object({
  prospectName:      z.string().min(2),
  prospectWebsite:   z.string().url().optional(),
  prospectCountry:   z.string().min(1),
  prospectIndustry:  z.string().min(1),
  contactName:       z.string().min(2),
  contactEmail:      z.string().email(),
  contactPhone:      z.string().min(7),
  dealName:          z.string().min(3),
  products:          z.array(z.string()).min(1),
  estimatedValue:    z.number().positive(),
  dealSource:        z.string().min(1),
  expectedCloseDate: z.string(),
  description:       z.string().min(100).max(2000),
  incumbent:         z.string().optional(),
})

const updateStatusSchema = z.object({
  status:          z.enum(['UNDER_REVIEW','ACCEPTED','REJECTED','IN_PROGRESS','WON','LOST']),
  reason:          z.string().optional(),
  assignedAmId:    z.string().uuid().optional(),
})

export default async function dealRoutes(fastify: FastifyInstance) {

  // ── GET /deals  ──────────────────────────────────────────────────────────────
  fastify.get('/', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    const q = req.query as Record<string, string>

    const where: Record<string, unknown> = {}

    // Partners only see their own deals
    if (jwtUser!.partnerId) {
      where.partnerId = jwtUser!.partnerId
    }
    if (q.status)         where.status = q.status
    if (q.assignedAmId)   where.assignedAmId = q.assignedAmId
    if (q.search) {
      where.OR = [
        { dealName:     { contains: q.search, mode: 'insensitive' } },
        { prospectName: { contains: q.search, mode: 'insensitive' } },
      ]
    }

    const page     = Math.max(1, Number(q.page ?? 1))
    const pageSize = Math.min(50, Number(q.pageSize ?? 20))
    const skip     = (page - 1) * pageSize

    const [data, total] = await Promise.all([
      prisma.deal.findMany({
        where,
        include: { assignedAm: { select: { id: true, name: true, email: true } } },
        orderBy: { createdAt: 'desc' },
        skip,
        take: pageSize,
      }),
      prisma.deal.count({ where }),
    ])

    return reply.send({ data, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
  })

  // ── POST /deals  ─────────────────────────────────────────────────────────────
  fastify.post('/', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    if (!jwtUser!.partnerId) {
      return reply.code(403).send({ error: 'Forbidden', message: 'Partner account required' })
    }

    const body = createDealSchema.parse(req.body)

    // Duplicate detection: same prospect + same partner
    const dupe = await prisma.deal.findFirst({
      where: {
        partnerId:    jwtUser!.partnerId,
        prospectName: { equals: body.prospectName, mode: 'insensitive' },
        status:       { notIn: ['REJECTED', 'LOST', 'EXPIRED'] },
      },
    })
    if (dupe) {
      return reply.code(409).send({
        error:   'Conflict',
        message: `An active deal for "${body.prospectName}" already exists (${dupe.id})`,
        existingDealId: dupe.id,
      })
    }

    const expiryDate = new Date()
    expiryDate.setDate(expiryDate.getDate() + 90)

    const deal = await DealService.create({
      ...body,
      partnerId:  jwtUser!.partnerId,
      expiryDate,
    })

    // Notify sales team
    await NotificationService.notifySalesTeam({
      type:    'NEW_DEAL',
      title:   'New Deal Registration',
      body:    `${deal.partner?.companyName} registered deal: ${deal.dealName} ($${body.estimatedValue.toLocaleString()})`,
      metadata:{ dealId: deal.id },
    })

    return reply.code(201).send(deal)
  })

  // ── GET /deals/:id ───────────────────────────────────────────────────────────
  fastify.get('/:id', { preHandler: authenticate }, async (req, reply) => {
    const { id } = req.params as { id: string }
    const { jwtUser } = req

    const deal = await prisma.deal.findUnique({
      where: { id },
      include: {
        partner:     { select: { id: true, companyName: true, tier: true } },
        assignedAm:  { select: { id: true, name: true, email: true, avatarUrl: true } },
        attachments: true,
        milestones:  { orderBy: { order: 'asc' } },
      },
    })

    if (!deal) return reply.code(404).send({ error: 'Not Found', message: 'Deal not found' })

    // Partners can only see their own deals
    if (jwtUser!.partnerId && deal.partnerId !== jwtUser!.partnerId) {
      return reply.code(403).send({ error: 'Forbidden' })
    }

    return reply.send(deal)
  })

  // ── PATCH /deals/:id/status  ─────────────────────────────────────────────────
  fastify.patch(
    '/:id/status',
    { preHandler: requireRoles(['SALES_REP', 'PARTNER_MANAGER', 'ACCOUNT_MANAGER', 'PORTAL_ADMIN']) },
    async (req, reply) => {
      const { id }    = req.params as { id: string }
      const { jwtUser } = req
      const body      = updateStatusSchema.parse(req.body)

      const deal = await prisma.deal.findUnique({ where: { id } })
      if (!deal) return reply.code(404).send({ error: 'Not Found' })

      const updated = await DealService.updateStatus(id, {
        status:       body.status as DealStatus,
        reason:       body.reason,
        assignedAmId: body.assignedAmId,
        changedById:  jwtUser!.dbId,
        fromStatus:   deal.status,
      })

      // Notify partner of status change
      await NotificationService.notifyPartner({
        partnerId: deal.partnerId,
        type:      'DEAL_STATUS_CHANGED',
        title:     `Deal ${body.status.replace('_', ' ')}`,
        body:      `Your deal "${deal.dealName}" has been updated to ${body.status}`,
        metadata:  { dealId: id, status: body.status },
      })

      return reply.send(updated)
    }
  )

  // ── DELETE /deals/:id/attachments/:fileId ────────────────────────────────────
  fastify.delete('/:id/attachments/:fileId', { preHandler: authenticate }, async (req, reply) => {
    const { fileId } = req.params as { id: string; fileId: string }
    await prisma.dealAttachment.delete({ where: { id: fileId } })
    return reply.code(204).send()
  })
}
