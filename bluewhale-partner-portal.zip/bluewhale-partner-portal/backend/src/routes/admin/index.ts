import type { FastifyInstance } from 'fastify'
import { prisma }              from '../config/db'
import { requireRoles }        from '../middleware/auth'

export default async function adminRoutes(fastify: FastifyInstance) {

  // ── GET /admin/dashboard — executive KPI snapshot ─────────────────────────
  fastify.get(
    '/dashboard',
    { preHandler: requireRoles(['PORTAL_ADMIN', 'EXECUTIVE']) },
    async (_req, reply) => {
      const [
        totalPartners,
        activePartners,
        totalDeals,
        wonDeals,
        pipelineAgg,
        pendingDiscounts,
        tierBreakdown,
      ] = await Promise.all([
        prisma.partner.count(),
        prisma.partner.count({ where: { status: 'ACTIVE' } }),
        prisma.deal.count(),
        prisma.deal.count({ where: { status: 'WON' } }),
        prisma.deal.aggregate({
          where: { status: { in: ['ACCEPTED', 'IN_PROGRESS'] } },
          _sum:  { estimatedValueUsd: true },
        }),
        prisma.discount.count({ where: { status: 'PENDING' } }),
        prisma.partner.groupBy({
          by:      ['tier'],
          _count:  { id: true },
        }),
      ])

      return reply.send({
        totalPartners,
        activePartners,
        totalDeals,
        wonDeals,
        winRate:         totalDeals > 0 ? Math.round((wonDeals / totalDeals) * 100) : 0,
        pipelineValue:   Number(pipelineAgg._sum.estimatedValueUsd ?? 0),
        pendingDiscounts,
        tierBreakdown:   Object.fromEntries(tierBreakdown.map(t => [t.tier, t._count.id])),
      })
    }
  )

  // ── GET /admin/users — user management ────────────────────────────────────
  fastify.get(
    '/users',
    { preHandler: requireRoles(['PORTAL_ADMIN']) },
    async (req, reply) => {
      const q        = req.query as Record<string, string>
      const page     = Math.max(1, Number(q.page ?? 1))
      const pageSize = Math.min(100, Number(q.pageSize ?? 50))

      const [data, total] = await Promise.all([
        prisma.user.findMany({
          include: { partner: { select: { companyName: true } } },
          orderBy: { createdAt: 'desc' },
          skip:    (page - 1) * pageSize,
          take:    pageSize,
        }),
        prisma.user.count(),
      ])

      return reply.send({ data, total, page, pageSize })
    }
  )

  // ── PATCH /admin/users/:id/role ───────────────────────────────────────────
  fastify.patch(
    '/users/:id/role',
    { preHandler: requireRoles(['PORTAL_ADMIN']) },
    async (req, reply) => {
      const { id }   = req.params as { id: string }
      const { role } = req.body as { role: string }

      const user = await prisma.user.update({
        where: { id },
        data:  { role: role as never },
        select: { id: true, name: true, email: true, role: true },
      })

      return reply.send(user)
    }
  )

  // ── GET /admin/tier-applications — PM approvals queue ─────────────────────
  fastify.get(
    '/tier-applications',
    { preHandler: requireRoles(['PARTNER_MANAGER', 'PORTAL_ADMIN']) },
    async (_req, reply) => {
      const applications = await prisma.tierApplication.findMany({
        where:   { status: 'PENDING' },
        include: { partner: { select: { companyName: true, tier: true, annualRevenue: true } } },
        orderBy: { createdAt: 'asc' },
      })
      return reply.send(applications)
    }
  )

  // ── PATCH /admin/tier-applications/:id ────────────────────────────────────
  fastify.patch(
    '/tier-applications/:id',
    { preHandler: requireRoles(['PARTNER_MANAGER', 'PORTAL_ADMIN']) },
    async (req, reply) => {
      const { id }              = req.params as { id: string }
      const { jwtUser }         = req
      const { status, feedback} = req.body as { status: 'APPROVED' | 'REJECTED'; feedback?: string }

      const application = await prisma.tierApplication.update({
        where: { id },
        data:  {
          status,
          reviewedById: jwtUser!.dbId,
          reviewedAt:   new Date(),
          notes:        feedback,
        },
        include: { partner: true },
      })

      if (status === 'APPROVED') {
        await prisma.partner.update({
          where: { id: application.partnerId },
          data:  { tier: application.requestedTier },
        })
      }

      return reply.send(application)
    }
  )
}
