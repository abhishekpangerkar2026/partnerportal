import type { FastifyInstance } from 'fastify'
import { z }                   from 'zod'
import { prisma }              from '../config/db'
import { authenticate, requireRoles } from '../middleware/auth'
import { NotificationService } from '../services/NotificationService'
import { EmailService }        from '../services/EmailService'

const TIER_CEILINGS: Record<string, number> = {
  REGISTERED: 10,
  SILVER:     20,
  GOLD:       30,
  PLATINUM:   40,
}

// Discount > 40% requires CEO/COO approval
const EXECUTIVE_THRESHOLD = 40

const createDiscountSchema = z.object({
  dealId:       z.string().uuid(),
  product:      z.string().min(1),
  listPriceUsd: z.number().positive(),
  requestedPct: z.number().min(1).max(60),
  justification:z.string().min(150),
})

const decisionSchema = z.object({
  approvedPct:     z.number().min(1).max(60).optional(),
  rejectionReason: z.string().optional(),
  counterOffer:    z.number().min(1).max(60).optional(),
})

export default async function discountRoutes(fastify: FastifyInstance) {

  // ── POST /discounts  ──────────────────────────────────────────────────────
  fastify.post('/', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    if (!jwtUser!.partnerId) return reply.code(403).send({ error: 'Forbidden' })

    const body = createDiscountSchema.parse(req.body)

    // Verify deal is accessible and accepted
    const deal = await prisma.deal.findFirst({
      where:   { id: body.dealId, partnerId: jwtUser!.partnerId },
      include: { partner: { select: { tier: true } } },
    })
    if (!deal) return reply.code(404).send({ error: 'Deal not found' })
    if (!['ACCEPTED', 'IN_PROGRESS'].includes(deal.status)) {
      return reply.code(422).send({
        error:   'Unprocessable',
        message: 'Discounts can only be requested on accepted or in-progress deals',
      })
    }

    const ceiling           = TIER_CEILINGS[deal.partner!.tier] ?? 10
    const requiresEscalation = body.requestedPct > ceiling

    const discount = await prisma.discount.create({
      data: {
        dealId:            body.dealId,
        partnerId:         jwtUser!.partnerId,
        product:           body.product,
        listPriceUsd:      body.listPriceUsd,
        requestedPct:      body.requestedPct,
        justification:     body.justification,
        requiresEscalation,
        status:            'PENDING',
      },
    })

    // Notify appropriate approver
    if (requiresEscalation) {
      // Above tier ceiling → notify Finance + Sales VP
      await NotificationService.notifyUser_byRole({
        roles:    ['FINANCE_APPROVER', 'PORTAL_ADMIN'],
        type:     'DISCOUNT_ESCALATION',
        title:    `Discount Exception — ${body.requestedPct}% (above ${ceiling}% tier limit)`,
        body:     `Partner requested ${body.requestedPct}% discount on "${deal.dealName}". Their tier ceiling is ${ceiling}%.`,
        metadata: { discountId: discount.id, dealId: body.dealId },
      })
    } else {
      // Within ceiling → notify AM
      if (deal.assignedAmId) {
        await NotificationService.notifyUser({
          userId:   deal.assignedAmId,
          type:     'DISCOUNT_REQUEST',
          title:    `Discount Request — ${body.requestedPct}%`,
          body:     `A ${body.requestedPct}% discount has been requested on deal "${deal.dealName}".`,
          metadata: { discountId: discount.id, dealId: body.dealId },
        })
      }
    }

    return reply.code(201).send({ ...discount, requiresEscalation, tierCeiling: ceiling })
  })

  // ── GET /discounts  ───────────────────────────────────────────────────────
  fastify.get('/', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    const q           = req.query as Record<string, string>

    const where: Record<string, unknown> = {}
    if (jwtUser!.partnerId)  where.partnerId = jwtUser!.partnerId
    if (q.status)            where.status    = q.status
    if (q.dealId)            where.dealId    = q.dealId
    if (q.escalated === 'true') where.requiresEscalation = true

    const page     = Math.max(1, Number(q.page ?? 1))
    const pageSize = Math.min(50, Number(q.pageSize ?? 20))

    const [data, total] = await Promise.all([
      prisma.discount.findMany({
        where,
        include: {
          deal:       { select: { id: true, dealName: true, estimatedValueUsd: true } },
          approvedBy: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip:    (page - 1) * pageSize,
        take:    pageSize,
      }),
      prisma.discount.count({ where }),
    ])

    return reply.send({ data, total, page, pageSize })
  })

  // ── PATCH /discounts/:id/approve  ─────────────────────────────────────────
  fastify.patch(
    '/:id/approve',
    { preHandler: requireRoles(['ACCOUNT_MANAGER', 'SALES_REP', 'FINANCE_APPROVER', 'PORTAL_ADMIN']) },
    async (req, reply) => {
      const { id }  = req.params as { id: string }
      const { jwtUser } = req
      const body    = decisionSchema.parse(req.body)

      const discount = await prisma.discount.findUnique({
        where:   { id },
        include: { deal: { select: { dealName: true, partnerId: true } } },
      })
      if (!discount) return reply.code(404).send({ error: 'Not Found' })

      const approvedPct = body.approvedPct ?? Number(discount.requestedPct)

      const updated = await prisma.discount.update({
        where: { id },
        data:  {
          status:      'APPROVED',
          approvedPct,
          approvedById: jwtUser!.dbId,
          approvedAt:   new Date(),
        },
      })

      // Notify partner
      await NotificationService.notifyPartner({
        partnerId: discount.deal.partnerId,
        type:      'DISCOUNT_DECISION',
        title:     `Discount Approved — ${approvedPct}%`,
        body:      `Your ${approvedPct}% discount request on "${discount.deal.dealName}" has been approved.`,
        metadata:  { discountId: id, dealId: discount.dealId, status: 'APPROVED', pct: approvedPct },
      })

      return reply.send(updated)
    }
  )

  // ── PATCH /discounts/:id/reject  ──────────────────────────────────────────
  fastify.patch(
    '/:id/reject',
    { preHandler: requireRoles(['ACCOUNT_MANAGER', 'SALES_REP', 'FINANCE_APPROVER', 'PORTAL_ADMIN']) },
    async (req, reply) => {
      const { id }  = req.params as { id: string }
      const body    = decisionSchema.parse(req.body)

      const discount = await prisma.discount.findUnique({
        where:   { id },
        include: { deal: { select: { dealName: true, partnerId: true } } },
      })
      if (!discount) return reply.code(404).send({ error: 'Not Found' })
      if (!body.rejectionReason) {
        return reply.code(400).send({ error: 'Bad Request', message: 'Rejection reason is required' })
      }

      const updated = await prisma.discount.update({
        where: { id },
        data:  { status: 'REJECTED', rejectionReason: body.rejectionReason },
      })

      await NotificationService.notifyPartner({
        partnerId: discount.deal.partnerId,
        type:      'DISCOUNT_DECISION',
        title:     'Discount Request Rejected',
        body:      `Your discount request on "${discount.deal.dealName}" was not approved. Reason: ${body.rejectionReason}`,
        metadata:  { discountId: id, dealId: discount.dealId, status: 'REJECTED' },
      })

      return reply.send(updated)
    }
  )

  // ── PATCH /discounts/:id/counter  ─────────────────────────────────────────
  fastify.patch(
    '/:id/counter',
    { preHandler: requireRoles(['ACCOUNT_MANAGER', 'FINANCE_APPROVER', 'PORTAL_ADMIN']) },
    async (req, reply) => {
      const { id } = req.params as { id: string }
      const body   = decisionSchema.parse(req.body)

      if (!body.counterOffer) {
        return reply.code(400).send({ error: 'Bad Request', message: 'counterOffer is required' })
      }

      const discount = await prisma.discount.findUnique({
        where:   { id },
        include: { deal: { select: { dealName: true, partnerId: true } } },
      })
      if (!discount) return reply.code(404).send({ error: 'Not Found' })

      const updated = await prisma.discount.update({
        where: { id },
        data:  { status: 'COUNTER_OFFERED', counterOffer: body.counterOffer },
      })

      await NotificationService.notifyPartner({
        partnerId: discount.deal.partnerId,
        type:      'DISCOUNT_COUNTER',
        title:     `Discount Counter-Offer — ${body.counterOffer}%`,
        body:      `A counter-offer of ${body.counterOffer}% has been made on your discount request for "${discount.deal.dealName}".`,
        metadata:  { discountId: id, dealId: discount.dealId },
      })

      return reply.send(updated)
    }
  )
}
