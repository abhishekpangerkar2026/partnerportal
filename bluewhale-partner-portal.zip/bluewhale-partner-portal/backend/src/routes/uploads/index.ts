import type { FastifyInstance } from 'fastify'
import { prisma }              from '../config/db'
import { authenticate }        from '../middleware/auth'
import { S3Service }           from '../services/S3Service'

const ALLOWED_TYPES = new Set([
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
])

export default async function uploadRoutes(fastify: FastifyInstance) {

  // POST /api/v1/deals/:id/attachments
  fastify.post('/:id/attachments', { preHandler: authenticate }, async (req, reply) => {
    const { id }      = req.params as { id: string }
    const { jwtUser } = req

    // Verify deal ownership
    const deal = await prisma.deal.findFirst({
      where: jwtUser!.partnerId
        ? { id, partnerId: jwtUser!.partnerId }
        : { id },
    })
    if (!deal) return reply.code(404).send({ error: 'Deal not found' })

    const data  = await req.file()
    if (!data)  return reply.code(400).send({ error: 'No file provided' })

    if (!ALLOWED_TYPES.has(data.mimetype)) {
      return reply.code(400).send({
        error:   'Invalid file type',
        message: 'Only PDF, DOCX, PPTX, and XLSX files are allowed',
      })
    }

    const buffer = await data.toBuffer()
    if (buffer.length > 25 * 1024 * 1024) {
      return reply.code(400).send({ error: 'File too large', message: 'Maximum 25 MB per file' })
    }

    const { key, url } = await S3Service.uploadFile({
      buffer,
      mimeType: data.mimetype,
      fileName: data.filename,
      folder:   `deals/${id}`,
    })

    const attachment = await prisma.dealAttachment.create({
      data: {
        dealId:      id,
        fileName:    data.filename,
        fileUrl:     url,
        fileType:    data.mimetype,
        fileSize:    buffer.length,
        uploadedById: jwtUser!.dbId,
      },
    })

    return reply.code(201).send(attachment)
  })
}
