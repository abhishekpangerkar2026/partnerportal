'use client'

import { useQuery } from '@tanstack/react-query'
import { TrendingUp, FileText, Tag, Award } from 'lucide-react'
import { api } from '@/lib/api'

interface Stat {
  label: string
  value: string
  change: string
  positive: boolean
  icon: React.ElementType
  color: string
}

export function DashboardStats() {
  const { data, isLoading } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: () => api.get('/partners/me/stats').then(r => r.data),
  })

  const stats: Stat[] = [
    {
      label: 'Active Deals',
      value: data?.activeDeals ?? '—',
      change: '+3 this month',
      positive: true,
      icon: FileText,
      color: 'text-blue-600 bg-blue-50',
    },
    {
      label: 'Pipeline Value',
      value: data?.pipelineValue ? `$${(data.pipelineValue / 1000).toFixed(0)}K` : '—',
      change: '+18% vs last quarter',
      positive: true,
      icon: TrendingUp,
      color: 'text-emerald-600 bg-emerald-50',
    },
    {
      label: 'Discounts Used',
      value: data?.discountsUsed ?? '—',
      change: '4 pending approval',
      positive: false,
      icon: Tag,
      color: 'text-amber-600 bg-amber-50',
    },
    {
      label: 'Certifications',
      value: data?.certifications ?? '—',
      change: '2 expiring soon',
      positive: false,
      icon: Award,
      color: 'text-purple-600 bg-purple-50',
    },
  ]

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="stat-card animate-pulse">
            <div className="h-16 bg-gray-100 rounded" />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <div key={stat.label} className="stat-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">{stat.label}</p>
                <p className="mt-1 text-2xl font-semibold">{stat.value}</p>
              </div>
              <div className={`rounded-lg p-2 ${stat.color}`}>
                <Icon className="h-4 w-4" />
              </div>
            </div>
            <p className={`mt-2 text-xs ${stat.positive ? 'text-emerald-600' : 'text-amber-600'}`}>
              {stat.change}
            </p>
          </div>
        )
      })}
    </div>
  )
}
