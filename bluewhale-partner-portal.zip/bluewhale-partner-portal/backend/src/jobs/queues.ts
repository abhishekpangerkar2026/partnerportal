import { Queue } from 'bullmq'
import { redis }  from '../config/redis'

const connection = redis

export const emailQueue = new Queue('email', {
  connection,
  defaultJobOptions: {
    attempts:  3,
    backoff:   { type: 'exponential', delay: 5000 },
    removeOnComplete: { count: 100 },
    removeOnFail:     { count: 500 },
  },
})

export const dealExpiryQueue = new Queue('deal-expiry', {
  connection,
  defaultJobOptions: {
    attempts: 2,
    removeOnComplete: true,
  },
})

export const notificationQueue = new Queue('notification', {
  connection,
  defaultJobOptions: {
    attempts:  3,
    backoff:   { type: 'fixed', delay: 3000 },
    removeOnComplete: { count: 200 },
  },
})

// Schedule deal expiry check every hour
dealExpiryQueue.add(
  'check-expiry',
  {},
  {
    repeat:  { pattern: '0 * * * *' }, // every hour
    jobId:   'deal-expiry-cron',
  }
)
