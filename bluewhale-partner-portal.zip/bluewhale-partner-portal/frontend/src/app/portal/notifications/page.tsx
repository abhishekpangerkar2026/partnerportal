'use client'

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api }          from '@/lib/api'
import { formatDistanceToNow } from 'date-fns'
import { Bell, CheckCheck } from 'lucide-react'
import type { Notification } from '@/types'

const TYPE_COLOR: Record<string, string> = {
  DEAL_STATUS_CHANGED:    'bg-blue-500',
  NEW_DEAL:               'bg-purple-500',
  DISCOUNT_REQUEST:       'bg-amber-500',
  DISCOUNT_ESCALATION:    'bg-red-500',
  DISCOUNT_DECISION:      'bg-emerald-500',
  TIER_APPLICATION:       'bg-brand-700',
  NEW_MESSAGE:            'bg-teal-500',
  TASK_ASSIGNED:          'bg-orange-500',
  NEW_PARTNER_REGISTRATION:'bg-indigo-500',
}

export default function NotificationsPage() {
  const queryClient = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['notifications'],
    queryFn:  () => api.get('/notifications').then(r => r.data),
  })

  const markAllMutation = useMutation({
    mutationFn: () => api.patch('/notifications/read-all'),
    onSuccess:  () => queryClient.invalidateQueries({ queryKey: ['notifications'] }),
  })

  const markMutation = useMutation({
    mutationFn: (id: string) => api.patch(`/notifications/${id}/read`),
    onSuccess:  () => queryClient.invalidateQueries({ queryKey: ['notifications'] }),
  })

  const notifications: Notification[] = data?.data ?? []
  const unread = notifications.filter(n => !n.readAt).length

  return (
    <div className="mx-auto max-w-2xl space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Notifications</h1>
          <p className="text-sm text-muted-foreground">{unread} unread</p>
        </div>
        {unread > 0 && (
          <button
            onClick={() => markAllMutation.mutate()}
            className="flex items-center gap-2 text-xs text-brand-700 hover:underline"
          >
            <CheckCheck className="h-3.5 w-3.5" /> Mark all read
          </button>
        )}
      </div>

      <div className="space-y-2">
        {isLoading
          ? [...Array(5)].map((_, i) => (
              <div key={i} className="h-16 animate-pulse rounded-xl bg-gray-100" />
            ))
          : notifications.length === 0
          ? (
              <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                <Bell className="mb-3 h-8 w-8 opacity-30" />
                <p className="text-sm">No notifications yet</p>
              </div>
            )
          : notifications.map(n => (
              <div
                key={n.id}
                onClick={() => !n.readAt && markMutation.mutate(n.id)}
                className={`flex items-start gap-3 rounded-xl border p-4 transition-colors cursor-pointer ${
                  n.readAt
                    ? 'bg-white opacity-70 dark:bg-gray-950'
                    : 'bg-white border-brand-200 dark:bg-gray-950'
                }`}
              >
                {/* Dot */}
                <div className="mt-1 flex-shrink-0">
                  <div className={`h-2.5 w-2.5 rounded-full ${TYPE_COLOR[n.type] ?? 'bg-gray-400'} ${n.readAt ? 'opacity-30' : ''}`} />
                </div>

                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium ${n.readAt ? 'text-muted-foreground' : 'text-gray-900 dark:text-white'}`}>
                    {n.title}
                  </p>
                  <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{n.body}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                  </p>
                </div>

                {!n.readAt && (
                  <div className="flex-shrink-0 h-2 w-2 mt-2 rounded-full bg-brand-700" />
                )}
              </div>
            ))
        }
      </div>
    </div>
  )
}
