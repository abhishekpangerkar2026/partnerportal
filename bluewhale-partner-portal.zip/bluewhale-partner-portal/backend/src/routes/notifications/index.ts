import type { FastifyInstance } from 'fastify'
import { authenticate }         from '../middleware/auth'
import { NotificationService }  from '../services/NotificationService'

export default async function notificationRoutes(fastify: FastifyInstance) {

  fastify.get('/', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    const q           = req.query as Record<string, string>
    const data        = await NotificationService.list(
      jwtUser!.dbId,
      Number(q.page ?? 1),
      Number(q.pageSize ?? 20),
    )
    return reply.send(data)
  })

  fastify.get('/unread-count', { preHandler: authenticate }, async (req, reply) => {
    const count = await NotificationService.getUnreadCount(req.jwtUser!.dbId)
    return reply.send({ count })
  })

  fastify.patch('/:id/read', { preHandler: authenticate }, async (req, reply) => {
    const { id } = req.params as { id: string }
    await NotificationService.markRead(id, req.jwtUser!.dbId)
    return reply.code(204).send()
  })

  fastify.patch('/read-all', { preHandler: authenticate }, async (req, reply) => {
    await NotificationService.markAllRead(req.jwtUser!.dbId)
    return reply.code(204).send()
  })
}
