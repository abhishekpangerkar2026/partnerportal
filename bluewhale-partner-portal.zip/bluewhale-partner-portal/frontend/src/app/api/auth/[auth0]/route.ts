import { handleAuth, handleCallback, handleLogin } from '@auth0/nextjs-auth0'

export const GET = handleAuth({
  login: handleLogin({
    returnTo: '/portal/dashboard',
  }),
  callback: handleCallback({
    afterCallback: async (_req, session) => {
      // After Auth0 callback, provision user in our DB
      try {
        const role = session.user['https://partnerportal.bluewhalestack.com/role'] ?? 'partner_user'
        await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/provision`, {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            auth0Id: session.user.sub,
            email:   session.user.email,
            name:    session.user.name,
            role,
          }),
        })
      } catch (e) {
        console.error('User provision failed:', e)
      }
      return session
    },
  }),
})
