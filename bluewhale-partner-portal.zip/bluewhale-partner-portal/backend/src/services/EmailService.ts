import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)
const FROM   = process.env.EMAIL_FROM ?? 'noreply@bluewhalestack.com'

export interface EmailPayload {
  to:      string | string[]
  subject: string
  html:    string
}

export const EmailService = {

  async send(payload: EmailPayload) {
    try {
      const result = await resend.emails.send({
        from:    FROM,
        to:      payload.to,
        subject: payload.subject,
        html:    payload.html,
      })
      return result
    } catch (err) {
      console.error('[EmailService] Failed to send email:', err)
      throw err
    }
  },

  // ── Template helpers ───────────────────────────────────────────────────────

  dealSubmitted(opts: { to: string; partnerName: string; dealName: string; dealId: string }) {
    return EmailService.send({
      to:      opts.to,
      subject: `Deal Registration Received — ${opts.dealName}`,
      html:    baseTemplate(`
        <h2 style="color:#003b6f">Deal Registration Confirmed</h2>
        <p>Hi ${opts.partnerName},</p>
        <p>Your deal registration has been received and is now under review by the BlueWhale Stack sales team.</p>
        <table style="border-collapse:collapse;width:100%;margin:16px 0">
          <tr><td style="padding:8px;border:1px solid #e2e8f0;color:#64748b">Deal Name</td>
              <td style="padding:8px;border:1px solid #e2e8f0;font-weight:600">${opts.dealName}</td></tr>
          <tr><td style="padding:8px;border:1px solid #e2e8f0;color:#64748b">Deal ID</td>
              <td style="padding:8px;border:1px solid #e2e8f0;font-family:monospace">${opts.dealId.slice(0,8).toUpperCase()}</td></tr>
          <tr><td style="padding:8px;border:1px solid #e2e8f0;color:#64748b">SLA</td>
              <td style="padding:8px;border:1px solid #e2e8f0">Response within 72 hours</td></tr>
        </table>
        ${ctaButton('View Deal Status', `${process.env.FRONTEND_URL}/portal/deals/${opts.dealId}`)}
      `),
    })
  },

  dealStatusChanged(opts: { to: string; dealName: string; status: string; dealId: string; reason?: string }) {
    const statusColors: Record<string, string> = {
      ACCEPTED:    '#16a34a',
      REJECTED:    '#dc2626',
      IN_PROGRESS: '#7c3aed',
      WON:         '#059669',
      LOST:        '#6b7280',
    }
    const color = statusColors[opts.status] ?? '#003b6f'

    return EmailService.send({
      to:      opts.to,
      subject: `Deal Update: ${opts.dealName} — ${opts.status.replace('_', ' ')}`,
      html:    baseTemplate(`
        <h2 style="color:#003b6f">Deal Status Updated</h2>
        <p>Your deal <strong>${opts.dealName}</strong> has been updated:</p>
        <div style="display:inline-block;padding:6px 16px;border-radius:999px;background:${color};color:#fff;font-weight:600;margin:12px 0">
          ${opts.status.replace('_', ' ')}
        </div>
        ${opts.reason ? `<p style="color:#64748b;font-style:italic">Reason: ${opts.reason}</p>` : ''}
        ${ctaButton('View Deal', `${process.env.FRONTEND_URL}/portal/deals/${opts.dealId}`)}
      `),
    })
  },

  discountDecision(opts: { to: string; dealName: string; status: string; pct: number; dealId: string }) {
    const approved = opts.status === 'APPROVED'
    return EmailService.send({
      to:      opts.to,
      subject: `Discount ${approved ? 'Approved' : 'Update'} — ${opts.dealName}`,
      html:    baseTemplate(`
        <h2 style="color:#003b6f">Discount ${approved ? 'Approved' : 'Decision'}</h2>
        <p>A discount decision has been made for deal <strong>${opts.dealName}</strong>.</p>
        <p style="font-size:28px;font-weight:700;color:${approved ? '#16a34a' : '#dc2626'}">
          ${opts.pct}% ${approved ? 'Approved' : opts.status}
        </p>
        ${approved
          ? '<p>Your discount authorization letter is available in the deal workspace.</p>'
          : '<p>Please contact your Partner Manager for further discussion.</p>'
        }
        ${ctaButton('View Deal Workspace', `${process.env.FRONTEND_URL}/portal/deals/${opts.dealId}/workspace`)}
      `),
    })
  },

  partnerApproved(opts: { to: string; partnerName: string; loginUrl: string }) {
    return EmailService.send({
      to:      opts.to,
      subject: 'Welcome to BlueWhale Stack Partner Network!',
      html:    baseTemplate(`
        <h2 style="color:#003b6f">You're officially a BlueWhale Stack Partner!</h2>
        <p>Hi ${opts.partnerName},</p>
        <p>Your partner application has been approved. You now have full access to the BlueWhale Stack Partner Portal.</p>
        <ul style="color:#475569;line-height:2">
          <li>Register and protect your deals</li>
          <li>Apply for partner discounts</li>
          <li>Access training and certification</li>
          <li>Collaborate with your dedicated Partner Manager</li>
        </ul>
        ${ctaButton('Access Partner Portal', opts.loginUrl)}
      `),
    })
  },

  newWorkspaceMessage(opts: { to: string; dealName: string; authorName: string; dealId: string }) {
    return EmailService.send({
      to:      opts.to,
      subject: `New message in "${opts.dealName}"`,
      html:    baseTemplate(`
        <h2 style="color:#003b6f">New message in your deal workspace</h2>
        <p><strong>${opts.authorName}</strong> posted a message in the workspace for deal <strong>${opts.dealName}</strong>.</p>
        ${ctaButton('View Message', `${process.env.FRONTEND_URL}/portal/deals/${opts.dealId}/workspace`)}
      `),
    })
  },
}

// ── Template wrappers ─────────────────────────────────────────────────────────

function baseTemplate(content: string) {
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
  <div style="max-width:600px;margin:32px auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0">
    <div style="background:#003b6f;padding:20px 32px;display:flex;align-items:center;gap:12px">
      <div style="width:32px;height:32px;background:#0096d6;border-radius:8px;display:flex;align-items:center;justify-content:center">
        <span style="color:#fff;font-weight:700;font-size:12px">BW</span>
      </div>
      <span style="color:#fff;font-weight:600;font-size:16px">BlueWhale Stack Partner Portal</span>
    </div>
    <div style="padding:32px">${content}</div>
    <div style="background:#f8fafc;padding:16px 32px;border-top:1px solid #e2e8f0;text-align:center">
      <p style="margin:0;font-size:12px;color:#94a3b8">
        © ${new Date().getFullYear()} BlueWhale Stack · 
        <a href="${process.env.FRONTEND_URL}/portal/settings/notifications" style="color:#0096d6">Manage notifications</a>
      </p>
    </div>
  </div>
</body></html>`
}

function ctaButton(label: string, url: string) {
  return `<a href="${url}" style="display:inline-block;margin:16px 0;padding:12px 24px;background:#003b6f;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;font-size:14px">${label}</a>`
}
