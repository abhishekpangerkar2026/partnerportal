import type { Metadata } from 'next'
import { DashboardStats }   from '@/components/dashboard/DashboardStats'
import { DealPipelineChart } from '@/components/dashboard/DealPipelineChart'
import { RecentActivity }   from '@/components/dashboard/RecentActivity'
import { TierProgress }     from '@/components/dashboard/TierProgress'
import { QuickActions }     from '@/components/dashboard/QuickActions'

export const metadata: Metadata = { title: 'Dashboard' }

export default function DashboardPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Welcome back. Here's your partnership overview.</p>
      </div>

      {/* Stat cards */}
      <DashboardStats />

      {/* Main grid */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="xl:col-span-2 space-y-6">
          <DealPipelineChart />
          <RecentActivity />
        </div>
        <div className="space-y-6">
          <TierProgress />
          <QuickActions />
        </div>
      </div>
    </div>
  )
}
