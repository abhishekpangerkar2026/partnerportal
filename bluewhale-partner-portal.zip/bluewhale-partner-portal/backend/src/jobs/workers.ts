import { Worker }          from 'bullmq'
import { redis }           from '../config/redis'
import { prisma }          from '../config/db'
import { EmailService }    from '../services/EmailService'
import { DealService }     from '../services/DealService'

// ── Email Worker ──────────────────────────────────────────────────────────────

export const emailWorker = new Worker(
  'email',
  async (job) => {
    const { type, userId, title, body, notificationId } = job.data

    const user = await prisma.user.findUnique({
      where:  { id: userId },
      select: { email: true, name: true },
    })
    if (!user) return

    switch (type) {
      case 'DEAL_STATUS_CHANGED': {
        const meta = job.data.metadata as { dealId: string; status: string } | undefined
        if (!meta) break
        const deal = await prisma.deal.findUnique({
          where:  { id: meta.dealId },
          select: { dealName: true },
        })
        if (!deal) break
        await EmailService.dealStatusChanged({
          to:       user.email,
          dealName: deal.dealName,
          status:   meta.status,
          dealId:   meta.dealId,
        })
        break
      }

      case 'DISCOUNT_DECISION': {
        const meta = job.data.metadata as { dealId: string; status: string; pct: number } | undefined
        if (!meta) break
        const deal = await prisma.deal.findUnique({
          where:  { id: meta.dealId },
          select: { dealName: true },
        })
        if (!deal) break
        await EmailService.discountDecision({
          to:       user.email,
          dealName: deal.dealName,
          status:   meta.status,
          pct:      meta.pct,
          dealId:   meta.dealId,
        })
        break
      }

      case 'NEW_MESSAGE': {
        const meta = job.data.metadata as { dealId: string; authorName: string } | undefined
        if (!meta) break
        const deal = await prisma.deal.findUnique({
          where:  { id: meta.dealId },
          select: { dealName: true },
        })
        if (!deal) break
        await EmailService.newWorkspaceMessage({
          to:         user.email,
          dealName:   deal.dealName,
          authorName: meta.authorName,
          dealId:     meta.dealId,
        })
        break
      }

      default:
        // Generic notification email
        await EmailService.send({
          to:      user.email,
          subject: title,
          html:    `<p>${body}</p>`,
        })
    }
  },
  { connection: redis, concurrency: 5 }
)

emailWorker.on('failed', (job, err) => {
  console.error(`[EmailWorker] Job ${job?.id} failed:`, err.message)
})

// ── Deal Expiry Worker ────────────────────────────────────────────────────────

export const dealExpiryWorker = new Worker(
  'deal-expiry',
  async () => {
    const expired = await DealService.expireStaleDeals()
    console.info(`[DealExpiryWorker] Expired ${expired} stale deals`)
  },
  { connection: redis }
)

dealExpiryWorker.on('failed', (job, err) => {
  console.error(`[DealExpiryWorker] Job ${job?.id} failed:`, err.message)
})
