'use client'

import { useMutation, useQueryClient } from '@tanstack/react-query'
import { api }                          from '@/lib/api'
import { format }                       from 'date-fns'
import { Check }                        from 'lucide-react'
import type { WorkspaceMilestone }      from '@/types'

interface Props {
  dealId:     string
  milestones: WorkspaceMilestone[]
}

export function WorkspaceMilestones({ dealId, milestones }: Props) {
  const queryClient = useQueryClient()

  const toggleMutation = useMutation({
    mutationFn: ({ milestoneId, completed }: { milestoneId: string; completed: boolean }) =>
      api.patch(`/workspace/${dealId}/milestones/${milestoneId}`, { completed }).then(r => r.data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['workspace', dealId] }),
  })

  const completedCount = milestones.filter(m => m.completedAt).length
  const pct = milestones.length > 0
    ? Math.round((completedCount / milestones.length) * 100)
    : 0

  return (
    <div className="stat-card">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold">Deal Milestones</h3>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">{completedCount}/{milestones.length}</span>
          <span className="text-xs font-semibold text-brand-700">{pct}%</span>
        </div>
      </div>

      {/* Progress bar */}
      <div className="mb-5 h-1.5 w-full overflow-hidden rounded-full bg-gray-100">
        <div
          className="h-full rounded-full bg-brand-700 transition-all duration-700"
          style={{ width: `${pct}%` }}
        />
      </div>

      {/* Milestone steps */}
      <div className="flex items-start gap-0">
        {milestones.map((ms, i) => {
          const done = !!ms.completedAt
          const isLast = i === milestones.length - 1

          return (
            <div key={ms.id} className="flex flex-1 flex-col items-center">
              {/* Connector + node row */}
              <div className="flex w-full items-center">
                {/* Left connector */}
                <div className={`h-0.5 flex-1 ${i === 0 ? 'invisible' : done ? 'bg-brand-700' : 'bg-gray-200'}`} />

                {/* Node */}
                <button
                  onClick={() => toggleMutation.mutate({ milestoneId: ms.id, completed: !done })}
                  className={`relative flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                    done
                      ? 'border-brand-700 bg-brand-700 text-white'
                      : 'border-gray-300 bg-white text-gray-400 hover:border-brand-400'
                  }`}
                  title={done ? 'Mark incomplete' : 'Mark complete'}
                >
                  {done
                    ? <Check className="h-3.5 w-3.5" />
                    : <span className="text-xs font-semibold">{i + 1}</span>
                  }
                </button>

                {/* Right connector */}
                <div className={`h-0.5 flex-1 ${isLast ? 'invisible' : done && milestones[i + 1]?.completedAt ? 'bg-brand-700' : 'bg-gray-200'}`} />
              </div>

              {/* Label */}
              <div className="mt-2 text-center px-1">
                <p className={`text-[10px] font-medium leading-tight ${done ? 'text-brand-700' : 'text-muted-foreground'}`}>
                  {ms.label}
                </p>
                {ms.completedAt && (
                  <p className="text-[9px] text-emerald-600 mt-0.5">
                    {format(new Date(ms.completedAt), 'MMM d')}
                  </p>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
