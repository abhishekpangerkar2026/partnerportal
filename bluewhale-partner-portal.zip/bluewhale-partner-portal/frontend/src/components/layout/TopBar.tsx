'use client'

import { Bell, Search, Moon, Sun } from 'lucide-react'
import { useTheme } from 'next-themes'

export function TopBar() {
  const { theme, setTheme } = useTheme()

  return (
    <header className="flex h-14 items-center justify-between border-b bg-white px-6 dark:bg-gray-950">
      <div className="flex items-center gap-2 rounded-lg border bg-gray-50 px-3 py-1.5 dark:bg-gray-900">
        <Search className="h-3.5 w-3.5 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search deals, partners..."
          className="w-56 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className="rounded-lg p-2 text-muted-foreground hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>
        <button className="relative rounded-lg p-2 text-muted-foreground hover:bg-gray-100 dark:hover:bg-gray-800">
          <Bell className="h-4 w-4" />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500" />
        </button>
      </div>
    </header>
  )
}
