'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api }        from '@/lib/api'
import { CheckCircle, XCircle, Building2 } from 'lucide-react'

// ── Pending Approvals (tier applications + discount escalations) ──────────────

export function PendingApprovals() {
  const queryClient = useQueryClient()

  const { data: tierApps } = useQuery({
    queryKey: ['tier-applications'],
    queryFn:  () => api.get('/admin/tier-applications').then(r => r.data),
  })

  const { data: discounts } = useQuery({
    queryKey: ['escalated-discounts'],
    queryFn:  () => api.get('/discounts', { params: { escalated: 'true', status: 'PENDING' } }).then(r => r.data),
  })

  const approveTier = useMutation({
    mutationFn: (id: string) =>
      api.patch(`/admin/tier-applications/${id}`, { status: 'APPROVED' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tier-applications'] }),
  })

  const approveDiscount = useMutation({
    mutationFn: (id: string) => api.patch(`/discounts/${id}/approve`),
    onSuccess:  () => queryClient.invalidateQueries({ queryKey: ['escalated-discounts'] }),
  })

  const apps      = tierApps ?? []
  const escalated = discounts?.data ?? []
  const total     = apps.length + escalated.length

  return (
    <div className="stat-card">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold">Pending Approvals</h3>
        {total > 0 && (
          <span className="rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-semibold text-red-700">
            {total}
          </span>
        )}
      </div>

      <div className="space-y-2">
        {apps.slice(0, 3).map((app: { id: string; partner?: { companyName: string }; requestedTier: string }) => (
          <div key={app.id} className="flex items-center justify-between rounded-lg bg-purple-50 p-2.5">
            <div>
              <p className="text-xs font-medium">{app.partner?.companyName}</p>
              <p className="text-[10px] text-muted-foreground">Tier upgrade → {app.requestedTier}</p>
            </div>
            <div className="flex gap-1">
              <button
                onClick={() => approveTier.mutate(app.id)}
                className="rounded p-1 text-emerald-600 hover:bg-emerald-100"
              >
                <CheckCircle className="h-3.5 w-3.5" />
              </button>
              <button className="rounded p-1 text-red-500 hover:bg-red-100">
                <XCircle className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ))}

        {escalated.slice(0, 3).map((d: { id: string; deal?: { dealName: string }; requestedPct: number }) => (
          <div key={d.id} className="flex items-center justify-between rounded-lg bg-amber-50 p-2.5">
            <div>
              <p className="text-xs font-medium">{d.deal?.dealName}</p>
              <p className="text-[10px] text-amber-700">Discount exception: {Number(d.requestedPct)}%</p>
            </div>
            <button
              onClick={() => approveDiscount.mutate(d.id)}
              className="rounded p-1 text-emerald-600 hover:bg-emerald-100"
            >
              <CheckCircle className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}

        {total === 0 && (
          <p className="text-xs text-center text-muted-foreground py-4">
            No pending approvals
          </p>
        )}
      </div>
    </div>
  )
}

// ── Partner Health Snapshot ───────────────────────────────────────────────────

export function PartnerHealth() {
  const { data } = useQuery({
    queryKey: ['partner-health'],
    queryFn:  () => api.get('/admin/dashboard').then(r => r.data),
  })

  const tierBreakdown: Record<string, number> = data?.tierBreakdown ?? {}

  const tiers = [
    { label: 'Platinum', key: 'PLATINUM', color: 'bg-brand-700' },
    { label: 'Gold',     key: 'GOLD',     color: 'bg-amber-400' },
    { label: 'Silver',   key: 'SILVER',   color: 'bg-slate-400' },
    { label: 'Registered', key: 'REGISTERED', color: 'bg-gray-300' },
  ]

  const total = Object.values(tierBreakdown).reduce((a, b) => a + b, 0) || 1

  return (
    <div className="stat-card">
      <div className="mb-4 flex items-center gap-2">
        <Building2 className="h-4 w-4 text-muted-foreground" />
        <h3 className="text-sm font-semibold">Partner Tier Distribution</h3>
      </div>

      <div className="space-y-2.5">
        {tiers.map(t => {
          const count = tierBreakdown[t.key] ?? 0
          const pct   = Math.round((count / total) * 100)
          return (
            <div key={t.key}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">{t.label}</span>
                <span className="font-medium">{count}</span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-gray-100">
                <div
                  className={`h-full rounded-full ${t.color} transition-all duration-700`}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
