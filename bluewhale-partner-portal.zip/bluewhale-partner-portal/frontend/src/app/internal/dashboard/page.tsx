import type { Metadata } from 'next'
import { InternalStats }   from '@/components/internal/InternalStats'
import { DealQueue }       from '@/components/internal/DealQueue'
import { PartnerHealth }   from '@/components/internal/PartnerHealth'
import { PendingApprovals } from '@/components/internal/PendingApprovals'

export const metadata: Metadata = { title: 'Internal Dashboard' }

export default function InternalDashboard() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Internal Dashboard</h1>
        <p className="text-sm text-muted-foreground">Partner ecosystem overview and action queue</p>
      </div>

      <InternalStats />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="xl:col-span-2 space-y-6">
          <DealQueue />
        </div>
        <div className="space-y-6">
          <PendingApprovals />
          <PartnerHealth />
        </div>
      </div>
    </div>
  )
}
