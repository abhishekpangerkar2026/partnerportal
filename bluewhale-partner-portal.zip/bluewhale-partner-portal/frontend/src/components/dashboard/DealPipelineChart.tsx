'use client'

import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend,
} from 'recharts'
import { useQuery } from '@tanstack/react-query'
import { api } from '@/lib/api'

const MOCK_DATA = [
  { month: 'Nov', submitted: 4, accepted: 3, won: 1 },
  { month: 'Dec', submitted: 6, accepted: 5, won: 2 },
  { month: 'Jan', submitted: 5, accepted: 4, won: 3 },
  { month: 'Feb', submitted: 8, accepted: 7, won: 2 },
  { month: 'Mar', submitted: 7, accepted: 5, won: 4 },
  { month: 'Apr', submitted: 9, accepted: 8, won: 3 },
]

export function DealPipelineChart() {
  const { data } = useQuery({
    queryKey: ['deal-pipeline-chart'],
    queryFn: () => api.get('/partners/me/pipeline-chart').then(r => r.data),
    placeholderData: MOCK_DATA,
  })

  return (
    <div className="stat-card">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Deal Pipeline</h3>
          <p className="text-xs text-muted-foreground">Last 6 months activity</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data ?? MOCK_DATA} barSize={10} barGap={3}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
          <XAxis
            dataKey="month"
            tick={{ fontSize: 11, fill: '#94a3b8' }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: '#94a3b8' }}
            axisLine={false}
            tickLine={false}
            width={24}
          />
          <Tooltip
            contentStyle={{
              fontSize: 12,
              border: '1px solid #e2e8f0',
              borderRadius: 8,
              boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.05)',
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: 11, paddingTop: 12 }}
            formatter={(v) => v.charAt(0).toUpperCase() + v.slice(1)}
          />
          <Bar dataKey="submitted" fill="#93c5fd" radius={[4, 4, 0, 0]} />
          <Bar dataKey="accepted"  fill="#003b6f" radius={[4, 4, 0, 0]} />
          <Bar dataKey="won"       fill="#34d399" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
