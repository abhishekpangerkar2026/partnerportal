'use client'

import Link from 'next/link'
import { FileText, Tag, ArrowUpCircle, MessageSquare } from 'lucide-react'

const actions = [
  {
    label: 'Register New Deal',
    description: 'Submit a new deal for protection',
    href: '/portal/deals/new',
    icon: FileText,
    color: 'text-blue-600 bg-blue-50 hover:bg-blue-100',
  },
  {
    label: 'Apply Discount',
    description: 'Request pricing discount',
    href: '/portal/discounts/new',
    icon: Tag,
    color: 'text-amber-600 bg-amber-50 hover:bg-amber-100',
  },
  {
    label: 'Request Tier Upgrade',
    description: 'Apply for a higher tier',
    href: '/portal/settings/tier',
    icon: ArrowUpCircle,
    color: 'text-purple-600 bg-purple-50 hover:bg-purple-100',
  },
  {
    label: 'Contact Partner Manager',
    description: 'Message your assigned PM',
    href: '/portal/workspace',
    icon: MessageSquare,
    color: 'text-emerald-600 bg-emerald-50 hover:bg-emerald-100',
  },
]

export function QuickActions() {
  return (
    <div className="stat-card space-y-3">
      <h3 className="text-sm font-semibold">Quick Actions</h3>
      <div className="space-y-2">
        {actions.map((a) => {
          const Icon = a.icon
          return (
            <Link
              key={a.href}
              href={a.href}
              className={`flex items-center gap-3 rounded-lg p-2.5 transition-colors ${a.color}`}
            >
              <Icon className="h-4 w-4 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs font-semibold">{a.label}</p>
                <p className="text-[10px] opacity-70">{a.description}</p>
              </div>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
