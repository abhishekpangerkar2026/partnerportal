'use client'

import { useQuery } from '@tanstack/react-query'
import { formatDistanceToNow } from 'date-fns'
import { api } from '@/lib/api'

const MOCK_ACTIVITY = [
  { id: '1', type: 'deal_accepted',   message: 'Deal "Acme Corp – Platform" was accepted',      time: new Date(Date.now() - 1000 * 60 * 30) },
  { id: '2', type: 'discount_approved',message: 'Discount of 20% approved for deal #DL-0042',   time: new Date(Date.now() - 1000 * 60 * 90) },
  { id: '3', type: 'message',         message: 'Sarah Mitchell commented on deal #DL-0039',     time: new Date(Date.now() - 1000 * 60 * 180) },
  { id: '4', type: 'deal_submitted',  message: 'You submitted deal "TechFlow – Cloud Suite"',   time: new Date(Date.now() - 1000 * 60 * 60 * 5) },
  { id: '5', type: 'cert_earned',     message: 'Certification "BW Cloud Foundations" earned',   time: new Date(Date.now() - 1000 * 60 * 60 * 24) },
]

const TYPE_DOT: Record<string, string> = {
  deal_accepted:    'bg-green-500',
  deal_submitted:   'bg-blue-500',
  discount_approved:'bg-amber-500',
  message:          'bg-purple-500',
  cert_earned:      'bg-emerald-500',
  default:          'bg-gray-400',
}

export function RecentActivity() {
  const { data } = useQuery({
    queryKey: ['recent-activity'],
    queryFn: () => api.get('/partners/me/activity').then(r => r.data),
    placeholderData: MOCK_ACTIVITY,
  })

  return (
    <div className="stat-card">
      <h3 className="mb-4 text-sm font-semibold">Recent Activity</h3>
      <div className="space-y-3">
        {(data ?? MOCK_ACTIVITY).map((item: typeof MOCK_ACTIVITY[0]) => (
          <div key={item.id} className="flex items-start gap-3">
            <div className="mt-1.5 flex-shrink-0">
              <div className={`h-2 w-2 rounded-full ${TYPE_DOT[item.type] ?? TYPE_DOT.default}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-700 dark:text-gray-300">{item.message}</p>
              <p className="text-[10px] text-muted-foreground">
                {formatDistanceToNow(new Date(item.time), { addSuffix: true })}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
