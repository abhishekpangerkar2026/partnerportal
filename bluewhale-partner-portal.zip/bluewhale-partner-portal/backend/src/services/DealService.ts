import { prisma } from '../config/db'
import type { DealStatus } from '@prisma/client'

interface CreateDealInput {
  partnerId:         string
  prospectName:      string
  prospectWebsite?:  string
  prospectCountry:   string
  prospectIndustry:  string
  contactName:       string
  contactEmail:      string
  contactPhone:      string
  dealName:          string
  products:          string[]
  estimatedValue:    number
  dealSource:        string
  expectedCloseDate: string
  description:       string
  incumbent?:        string
  expiryDate:        Date
}

interface UpdateStatusInput {
  status:       DealStatus
  reason?:      string
  assignedAmId?: string
  changedById:  string
  fromStatus:   DealStatus
}

export const DealService = {

  async create(input: CreateDealInput) {
    const deal = await prisma.deal.create({
      data: {
        dealName:          input.dealName,
        partnerId:         input.partnerId,
        prospectName:      input.prospectName,
        prospectWebsite:   input.prospectWebsite,
        prospectCountry:   input.prospectCountry,
        prospectIndustry:  input.prospectIndustry,
        contactName:       input.contactName,
        contactEmail:      input.contactEmail,
        contactPhone:      input.contactPhone,
        products:          input.products,
        estimatedValueUsd: input.estimatedValue,
        dealSource:        input.dealSource,
        expectedCloseDate: new Date(input.expectedCloseDate),
        description:       input.description,
        incumbent:         input.incumbent,
        expiryDate:        input.expiryDate,
        status:            'SUBMITTED',
        milestones: {
          create: [
            { label: 'Discovery',             order: 1 },
            { label: 'Technical Validation',  order: 2 },
            { label: 'Proposal Submitted',    order: 3 },
            { label: 'Legal / Commercial',    order: 4 },
            { label: 'PO Received',           order: 5 },
          ],
        },
      },
      include: {
        partner:    { select: { id: true, companyName: true, tier: true } },
        milestones: true,
      },
    })

    // Record initial status history
    await prisma.dealStatusHistory.create({
      data: {
        dealId:      deal.id,
        toStatus:    'SUBMITTED',
        changedById: deal.partnerId, // submitted by partner
      },
    })

    return deal
  },

  async updateStatus(dealId: string, input: UpdateStatusInput) {
    const updateData: Record<string, unknown> = { status: input.status }

    if (input.assignedAmId)              updateData.assignedAmId  = input.assignedAmId
    if (input.status === 'REJECTED')     updateData.rejectionReason = input.reason
    if (input.status === 'WON' || input.status === 'LOST') {
      updateData.wonLostReason = input.reason
    }

    const [deal] = await prisma.$transaction([
      prisma.deal.update({
        where: { id: dealId },
        data:  updateData,
        include: {
          partner:    { select: { id: true, companyName: true } },
          assignedAm: { select: { id: true, name: true, email: true } },
        },
      }),
      prisma.dealStatusHistory.create({
        data: {
          dealId,
          fromStatus:  input.fromStatus,
          toStatus:    input.status,
          changedById: input.changedById,
          reason:      input.reason,
        },
      }),
    ])

    return deal
  },

  async getWithWorkspace(dealId: string) {
    return prisma.deal.findUnique({
      where: { id: dealId },
      include: {
        partner:    { select: { id: true, companyName: true, tier: true } },
        assignedAm: { select: { id: true, name: true, email: true, avatarUrl: true } },
        attachments: true,
        milestones:  { orderBy: { order: 'asc' } },
        messages: {
          orderBy: { createdAt: 'asc' },
          include: { author: { select: { id: true, name: true, avatarUrl: true, role: true } } },
        },
        tasks: {
          orderBy: { createdAt: 'desc' },
          include: {
            assignee:  { select: { id: true, name: true, avatarUrl: true } },
            createdBy: { select: { id: true, name: true } },
          },
        },
        discounts: {
          orderBy: { createdAt: 'desc' },
          include: { approvedBy: { select: { id: true, name: true } } },
        },
        statusHistory: {
          orderBy: { createdAt: 'asc' },
        },
      },
    })
  },

  async expireStaleDeals() {
    const result = await prisma.deal.updateMany({
      where: {
        status:     { in: ['SUBMITTED', 'UNDER_REVIEW', 'ACCEPTED', 'IN_PROGRESS'] },
        expiryDate: { lt: new Date() },
      },
      data: { status: 'EXPIRED' },
    })
    return result.count
  },

  async getStats(partnerId: string) {
    const [activeDeals, pipelineAgg, discounts, certs] = await Promise.all([
      prisma.deal.count({
        where: { partnerId, status: { in: ['SUBMITTED', 'UNDER_REVIEW', 'ACCEPTED', 'IN_PROGRESS'] } },
      }),
      prisma.deal.aggregate({
        where:   { partnerId, status: { in: ['ACCEPTED', 'IN_PROGRESS'] } },
        _sum:    { estimatedValueUsd: true },
      }),
      prisma.discount.count({
        where: { partnerId, status: 'PENDING' },
      }),
      Promise.resolve(0), // certifications — extend when training module is built
    ])

    return {
      activeDeals,
      pipelineValue:   Number(pipelineAgg._sum.estimatedValueUsd ?? 0),
      discountsUsed:   discounts,
      certifications:  certs,
    }
  },

  async getPipelineChart(partnerId: string) {
    const sixMonthsAgo = new Date()
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)

    const deals = await prisma.deal.findMany({
      where:  { partnerId, createdAt: { gte: sixMonthsAgo } },
      select: { createdAt: true, status: true },
    })

    const months: Record<string, { month: string; submitted: number; accepted: number; won: number }> = {}

    for (const deal of deals) {
      const key = deal.createdAt.toLocaleString('en-US', { month: 'short' })
      if (!months[key]) months[key] = { month: key, submitted: 0, accepted: 0, won: 0 }
      months[key].submitted++
      if (['ACCEPTED', 'IN_PROGRESS', 'WON'].includes(deal.status)) months[key].accepted++
      if (deal.status === 'WON') months[key].won++
    }

    return Object.values(months)
  },
}
