import type { FastifyInstance } from 'fastify'
import { z }                   from 'zod'
import { prisma }              from '../config/db'
import { authenticate }        from '../middleware/auth'
import type { UserRole }       from '@prisma/client'

const provisionSchema = z.object({
  auth0Id:   z.string(),
  email:     z.string().email(),
  name:      z.string(),
  role:      z.enum([
    'PARTNER_ADMIN','PARTNER_USER','PARTNER_MANAGER',
    'ACCOUNT_MANAGER','SALES_REP','FINANCE_APPROVER','PORTAL_ADMIN','EXECUTIVE',
  ]),
  partnerId: z.string().uuid().optional(),
})

export default async function authRoutes(fastify: FastifyInstance) {

  // Called after Auth0 login to create/sync user in DB
  fastify.post('/provision', async (req, reply) => {
    const body = provisionSchema.parse(req.body)

    const user = await prisma.user.upsert({
      where:  { auth0Id: body.auth0Id },
      create: {
        auth0Id:   body.auth0Id,
        email:     body.email,
        name:      body.name,
        role:      body.role as UserRole,
        partnerId: body.partnerId,
      },
      update: {
        email:       body.email,
        name:        body.name,
        lastLoginAt: new Date(),
      },
    })

    return reply.send(user)
  })

  // GET /auth/me — returns full user + partner info
  fastify.get('/me', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req

    const user = await prisma.user.findUnique({
      where:   { id: jwtUser!.dbId },
      include: {
        partner: {
          select: {
            id: true, companyName: true, tier: true,
            status: true, assignedPmId: true,
          },
        },
      },
    })

    if (!user) return reply.code(404).send({ error: 'User not found' })

    await prisma.user.update({
      where: { id: user.id },
      data:  { lastLoginAt: new Date() },
    })

    return reply.send(user)
  })
}
