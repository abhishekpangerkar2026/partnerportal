import type { FastifyInstance } from 'fastify'
import { z }                   from 'zod'
import { prisma }              from '../config/db'
import { authenticate }        from '../middleware/auth'
import { NotificationService } from '../services/NotificationService'
import type { Server }         from 'socket.io'

const messageSchema = z.object({
  content:    z.string().min(1).max(5000),
  isInternal: z.boolean().optional().default(false),
})

const taskSchema = z.object({
  title:       z.string().min(1).max(200),
  description: z.string().optional(),
  assigneeId:  z.string().uuid(),
  dueDate:     z.string(),
  priority:    z.enum(['LOW', 'MEDIUM', 'HIGH']).default('MEDIUM'),
})

const taskUpdateSchema = z.object({
  status:   z.enum(['OPEN', 'IN_PROGRESS', 'BLOCKED', 'COMPLETED']).optional(),
  title:    z.string().optional(),
  dueDate:  z.string().optional(),
  priority: z.enum(['LOW', 'MEDIUM', 'HIGH']).optional(),
})

export default async function workspaceRoutes(fastify: FastifyInstance) {
  // io is attached to fastify in server.ts
  const getIo = () => (fastify as unknown as { io: Server }).io

  // ── Helper: verify deal access ────────────────────────────────────────────
  async function verifyAccess(dealId: string, jwtUser: { partnerId?: string; dbId: string }) {
    const deal = await prisma.deal.findUnique({
      where:  { id: dealId },
      select: { partnerId: true, assignedAmId: true, status: true },
    })
    if (!deal) return null

    // Partners can only access their own deals
    if (jwtUser.partnerId && deal.partnerId !== jwtUser.partnerId) return null

    return deal
  }

  // ══ MESSAGES ════════════════════════════════════════════════════════════════

  // GET /workspace/:dealId/messages
  fastify.get('/:dealId/messages', { preHandler: authenticate }, async (req, reply) => {
    const { dealId }  = req.params as { dealId: string }
    const { jwtUser } = req

    const deal = await verifyAccess(dealId, jwtUser!)
    if (!deal) return reply.code(404).send({ error: 'Not Found' })

    // Partners cannot see internal messages
    const isPartner  = !!jwtUser!.partnerId
    const where      = isPartner ? { dealId, isInternal: false } : { dealId }

    const messages = await prisma.workspaceMessage.findMany({
      where,
      include: {
        author: { select: { id: true, name: true, avatarUrl: true, role: true } },
      },
      orderBy: { createdAt: 'asc' },
    })

    return reply.send(messages)
  })

  // POST /workspace/:dealId/messages
  fastify.post('/:dealId/messages', { preHandler: authenticate }, async (req, reply) => {
    const { dealId }  = req.params as { dealId: string }
    const { jwtUser } = req
    const body        = messageSchema.parse(req.body)

    // Partners cannot post internal messages
    if (jwtUser!.partnerId && body.isInternal) {
      return reply.code(403).send({ error: 'Forbidden', message: 'Partners cannot post internal notes' })
    }

    const deal = await verifyAccess(dealId, jwtUser!)
    if (!deal) return reply.code(404).send({ error: 'Not Found' })

    const message = await prisma.workspaceMessage.create({
      data: {
        dealId,
        authorId:   jwtUser!.dbId,
        content:    body.content,
        isInternal: body.isInternal,
      },
      include: {
        author: { select: { id: true, name: true, avatarUrl: true, role: true } },
      },
    })

    // Emit to all deal workspace subscribers
    getIo().to(`deal:${dealId}`).emit('workspace:message', message)

    // Notify partner (if internal user posted a partner-visible message)
    if (!body.isInternal && !jwtUser!.partnerId) {
      await NotificationService.notifyPartner({
        partnerId: deal.partnerId,
        type:      'NEW_MESSAGE',
        title:     'New message in your deal workspace',
        body:      `${message.author.name} posted a message in the workspace.`,
        metadata:  { dealId, authorName: message.author.name },
      })
    }

    return reply.code(201).send(message)
  })

  // ══ TASKS ═══════════════════════════════════════════════════════════════════

  // GET /workspace/:dealId/tasks
  fastify.get('/:dealId/tasks', { preHandler: authenticate }, async (req, reply) => {
    const { dealId }  = req.params as { dealId: string }
    const { jwtUser } = req

    const deal = await verifyAccess(dealId, jwtUser!)
    if (!deal) return reply.code(404).send({ error: 'Not Found' })

    const tasks = await prisma.workspaceTask.findMany({
      where:   { dealId },
      include: {
        assignee:  { select: { id: true, name: true, avatarUrl: true } },
        createdBy: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return reply.send(tasks)
  })

  // POST /workspace/:dealId/tasks
  fastify.post('/:dealId/tasks', { preHandler: authenticate }, async (req, reply) => {
    const { dealId }  = req.params as { dealId: string }
    const { jwtUser } = req
    const body        = taskSchema.parse(req.body)

    const deal = await verifyAccess(dealId, jwtUser!)
    if (!deal) return reply.code(404).send({ error: 'Not Found' })

    const task = await prisma.workspaceTask.create({
      data: {
        dealId,
        title:       body.title,
        description: body.description,
        assigneeId:  body.assigneeId,
        createdById: jwtUser!.dbId,
        dueDate:     new Date(body.dueDate),
        priority:    body.priority,
        status:      'OPEN',
      },
      include: {
        assignee:  { select: { id: true, name: true, avatarUrl: true } },
        createdBy: { select: { id: true, name: true } },
      },
    })

    getIo().to(`deal:${dealId}`).emit('workspace:task:created', task)

    // Notify assignee
    await NotificationService.notifyUser({
      userId:   body.assigneeId,
      type:     'TASK_ASSIGNED',
      title:    'New task assigned to you',
      body:     `"${body.title}" — due ${new Date(body.dueDate).toLocaleDateString()}`,
      metadata: { taskId: task.id, dealId },
    })

    return reply.code(201).send(task)
  })

  // PATCH /workspace/:dealId/tasks/:taskId
  fastify.patch('/:dealId/tasks/:taskId', { preHandler: authenticate }, async (req, reply) => {
    const { dealId, taskId } = req.params as { dealId: string; taskId: string }
    const body               = taskUpdateSchema.parse(req.body)

    const updateData: Record<string, unknown> = { ...body }
    if (body.dueDate)                  updateData.dueDate    = new Date(body.dueDate)
    if (body.status === 'COMPLETED')   updateData.completedAt = new Date()

    const task = await prisma.workspaceTask.update({
      where:   { id: taskId, dealId },
      data:    updateData,
      include: { assignee: { select: { id: true, name: true } } },
    })

    getIo().to(`deal:${dealId}`).emit('workspace:task:updated', task)

    return reply.send(task)
  })

  // ══ MILESTONES ══════════════════════════════════════════════════════════════

  // GET /workspace/:dealId/milestones
  fastify.get('/:dealId/milestones', { preHandler: authenticate }, async (req, reply) => {
    const { dealId }  = req.params as { dealId: string }
    const { jwtUser } = req

    const deal = await verifyAccess(dealId, jwtUser!)
    if (!deal) return reply.code(404).send({ error: 'Not Found' })

    const milestones = await prisma.workspaceMilestone.findMany({
      where:   { dealId },
      orderBy: { order: 'asc' },
    })

    return reply.send(milestones)
  })

  // PATCH /workspace/:dealId/milestones/:milestoneId
  fastify.patch(
    '/:dealId/milestones/:milestoneId',
    { preHandler: authenticate },
    async (req, reply) => {
      const { dealId, milestoneId } = req.params as { dealId: string; milestoneId: string }
      const { jwtUser }             = req
      const { completed }           = req.body as { completed: boolean }

      const milestone = await prisma.workspaceMilestone.update({
        where: { id: milestoneId, dealId },
        data:  {
          completedAt:   completed ? new Date() : null,
          completedById: completed ? jwtUser!.dbId : null,
        },
      })

      getIo().to(`deal:${dealId}`).emit('workspace:milestone:updated', milestone)

      return reply.send(milestone)
    }
  )

  // ══ WORKSPACE OVERVIEW ═══════════════════════════════════════════════════════

  // GET /workspace/:dealId
  fastify.get('/:dealId', { preHandler: authenticate }, async (req, reply) => {
    const { dealId }  = req.params as { dealId: string }
    const { jwtUser } = req

    const deal = await verifyAccess(dealId, jwtUser!)
    if (!deal) return reply.code(404).send({ error: 'Not Found' })

    const [messages, tasks, milestones, discounts] = await Promise.all([
      prisma.workspaceMessage.findMany({
        where:   jwtUser!.partnerId ? { dealId, isInternal: false } : { dealId },
        include: { author: { select: { id: true, name: true, avatarUrl: true, role: true } } },
        orderBy: { createdAt: 'asc' },
        take:    50,
      }),
      prisma.workspaceTask.findMany({
        where:   { dealId },
        include: { assignee: { select: { id: true, name: true, avatarUrl: true } } },
        orderBy: { dueDate: 'asc' },
      }),
      prisma.workspaceMilestone.findMany({
        where:   { dealId },
        orderBy: { order: 'asc' },
      }),
      prisma.discount.findMany({
        where:   { dealId },
        orderBy: { createdAt: 'desc' },
        take:    5,
      }),
    ])

    return reply.send({ messages, tasks, milestones, discounts })
  })
}
