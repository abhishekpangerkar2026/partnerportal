'use client'

import { useState }  from 'react'
import { useQuery }  from '@tanstack/react-query'
import Link          from 'next/link'
import { api }       from '@/lib/api'
import { formatCurrency } from '@/lib/utils'
import { format }    from 'date-fns'
import { Tag, TrendingDown, CheckCircle, XCircle, Clock, RefreshCw } from 'lucide-react'
import type { Discount } from '@/types'

const STATUS_CONFIG = {
  pending:        { label: 'Pending',        icon: Clock,          color: 'text-amber-600 bg-amber-50' },
  approved:       { label: 'Approved',       icon: CheckCircle,    color: 'text-emerald-600 bg-emerald-50' },
  rejected:       { label: 'Rejected',       icon: XCircle,        color: 'text-red-600 bg-red-50' },
  counter_offered:{ label: 'Counter Offered',icon: RefreshCw,      color: 'text-blue-600 bg-blue-50' },
}

export default function DiscountsPage() {
  const [statusFilter, setStatus] = useState('all')

  const { data, isLoading } = useQuery({
    queryKey: ['discounts', statusFilter],
    queryFn:  () =>
      api.get('/discounts', {
        params: statusFilter !== 'all' ? { status: statusFilter } : {},
      }).then(r => r.data),
  })

  const discounts: Discount[] = data?.data ?? []

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Discount Requests</h1>
          <p className="text-sm text-muted-foreground">Track and manage your pricing discount requests</p>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { label: 'Total Requests', value: data?.total ?? 0,                                    icon: Tag,          color: 'text-blue-600 bg-blue-50' },
          { label: 'Approved',       value: discounts.filter(d => d.status === 'approved').length, icon: CheckCircle,  color: 'text-emerald-600 bg-emerald-50' },
          { label: 'Pending',        value: discounts.filter(d => d.status === 'pending').length,  icon: Clock,        color: 'text-amber-600 bg-amber-50' },
          { label: 'Avg Approved %', value: (() => {
            const appr = discounts.filter(d => d.status === 'approved' && d.approvedPct)
            return appr.length ? `${Math.round(appr.reduce((s, d) => s + Number(d.approvedPct), 0) / appr.length)}%` : '—'
          })(), icon: TrendingDown, color: 'text-purple-600 bg-purple-50' },
        ].map(s => {
          const Icon = s.icon
          return (
            <div key={s.label} className="stat-card flex items-start justify-between">
              <div>
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="mt-1 text-2xl font-semibold">{s.value}</p>
              </div>
              <div className={`rounded-lg p-2 ${s.color}`}>
                <Icon className="h-4 w-4" />
              </div>
            </div>
          )
        })}
      </div>

      {/* Status filter */}
      <div className="flex gap-1 flex-wrap">
        {['all', 'pending', 'approved', 'rejected', 'counter_offered'].map(s => (
          <button
            key={s}
            onClick={() => setStatus(s)}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors capitalize ${
              statusFilter === s
                ? 'bg-brand-700 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {s.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Discounts table */}
      <div className="overflow-hidden rounded-xl border bg-white dark:bg-gray-950">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-gray-50 dark:bg-gray-900 text-xs text-muted-foreground">
              <th className="px-4 py-3 text-left font-medium">Deal</th>
              <th className="px-4 py-3 text-left font-medium">Product</th>
              <th className="px-4 py-3 text-left font-medium">List Price</th>
              <th className="px-4 py-3 text-left font-medium">Requested</th>
              <th className="px-4 py-3 text-left font-medium">Approved</th>
              <th className="px-4 py-3 text-left font-medium">Status</th>
              <th className="px-4 py-3 text-left font-medium">Date</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {isLoading
              ? [...Array(4)].map((_, i) => (
                  <tr key={i}>
                    {[...Array(7)].map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-4 animate-pulse rounded bg-gray-100" />
                      </td>
                    ))}
                  </tr>
                ))
              : discounts.length === 0
              ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-12 text-center text-sm text-muted-foreground">
                      No discount requests yet.{' '}
                      <Link href="/portal/deals" className="text-brand-700 underline">
                        Register a deal first
                      </Link>
                    </td>
                  </tr>
                )
              : discounts.map(d => {
                  const cfg   = STATUS_CONFIG[d.status as keyof typeof STATUS_CONFIG] ?? STATUS_CONFIG.pending
                  const Icon  = cfg.icon
                  const saved = d.approvedPct
                    ? formatCurrency(Number(d.listPriceUsd) * Number(d.approvedPct) / 100)
                    : null

                  return (
                    <tr key={d.id} className="hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors">
                      <td className="px-4 py-3">
                        <Link href={`/portal/deals/${d.dealId}`} className="text-brand-700 hover:underline text-xs font-medium">
                          {d.deal?.dealName ?? d.dealId.slice(0, 8)}
                        </Link>
                      </td>
                      <td className="px-4 py-3 text-xs">{d.product}</td>
                      <td className="px-4 py-3 text-xs font-medium">{formatCurrency(d.listPriceUsd)}</td>
                      <td className="px-4 py-3">
                        <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-semibold text-gray-700">
                          {Number(d.requestedPct)}%
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {d.approvedPct ? (
                          <div>
                            <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-700">
                              {Number(d.approvedPct)}%
                            </span>
                            {saved && <p className="text-[10px] text-emerald-600 mt-0.5">Save {saved}</p>}
                          </div>
                        ) : d.counterOffer ? (
                          <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-semibold text-blue-700">
                            {Number(d.counterOffer)}%
                          </span>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ${cfg.color}`}>
                          <Icon className="h-3 w-3" />
                          {cfg.label}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {format(new Date(d.createdAt), 'MMM d, yyyy')}
                      </td>
                    </tr>
                  )
                })
            }
          </tbody>
        </table>
      </div>
    </div>
  )
}
