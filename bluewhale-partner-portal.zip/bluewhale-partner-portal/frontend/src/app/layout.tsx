import type { Metadata } from 'next'
import { GeistSans } from 'geist/font/sans'
import { GeistMono } from 'geist/font/mono'
import { UserProvider } from '@auth0/nextjs-auth0/client'
import { ThemeProvider } from 'next-themes'
import { Providers } from '@/components/layout/Providers'
import './globals.css'

export const metadata: Metadata = {
  title: {
    default: 'BlueWhale Stack Partner Portal',
    template: '%s | BlueWhale Stack Partners',
  },
  description: 'Register deals, manage partnerships, and collaborate with the BlueWhale Stack team.',
  robots: { index: false, follow: false }, // private portal
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${GeistSans.variable} ${GeistMono.variable} font-sans antialiased`}>
        <UserProvider>
          <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
            <Providers>
              {children}
            </Providers>
          </ThemeProvider>
        </UserProvider>
      </body>
    </html>
  )
}
