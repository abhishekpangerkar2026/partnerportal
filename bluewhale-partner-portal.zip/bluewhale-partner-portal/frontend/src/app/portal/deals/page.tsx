'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useQuery } from '@tanstack/react-query'
import { Plus, Search, Filter } from 'lucide-react'
import { api } from '@/lib/api'
import { formatCurrency, DEAL_STATUS_LABEL, DEAL_STATUS_CLASS } from '@/lib/utils'
import type { Deal, DealStatus } from '@/types'
import { format } from 'date-fns'

const STATUS_FILTERS: { label: string; value: DealStatus | 'all' }[] = [
  { label: 'All',         value: 'all' },
  { label: 'Submitted',   value: 'submitted' },
  { label: 'Under Review',value: 'under_review' },
  { label: 'Accepted',    value: 'accepted' },
  { label: 'In Progress', value: 'in_progress' },
  { label: 'Won',         value: 'won' },
  { label: 'Lost',        value: 'lost' },
]

export default function DealsPage() {
  const [status, setStatus] = useState<DealStatus | 'all'>('all')
  const [search, setSearch] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['deals', status, search],
    queryFn: () =>
      api.get('/deals', { params: { status: status === 'all' ? undefined : status, search } })
        .then(r => r.data),
  })

  const deals: Deal[] = data?.data ?? []

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Deal Registrations</h1>
          <p className="text-sm text-muted-foreground">{data?.total ?? 0} total deals</p>
        </div>
        <Link href="/portal/deals/new" className="btn-primary flex items-center gap-2">
          <Plus className="h-4 w-4" /> Register Deal
        </Link>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 rounded-lg border bg-white px-3 py-1.5 dark:bg-gray-950">
          <Search className="h-3.5 w-3.5 text-muted-foreground" />
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search deals..." className="w-48 bg-transparent text-sm outline-none"
          />
        </div>
        <div className="flex gap-1">
          {STATUS_FILTERS.map(f => (
            <button
              key={f.value}
              onClick={() => setStatus(f.value)}
              className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
                status === f.value
                  ? 'bg-brand-700 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border bg-white dark:bg-gray-950">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-gray-50 dark:bg-gray-900 text-xs text-muted-foreground">
              <th className="px-4 py-3 text-left font-medium">Deal</th>
              <th className="px-4 py-3 text-left font-medium">Prospect</th>
              <th className="px-4 py-3 text-left font-medium">Value</th>
              <th className="px-4 py-3 text-left font-medium">Status</th>
              <th className="px-4 py-3 text-left font-medium">Close Date</th>
              <th className="px-4 py-3 text-left font-medium">AM</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {isLoading
              ? [...Array(5)].map((_, i) => (
                  <tr key={i}>
                    {[...Array(6)].map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-4 w-full animate-pulse rounded bg-gray-100" />
                      </td>
                    ))}
                  </tr>
                ))
              : deals.length === 0
              ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-12 text-center text-muted-foreground text-sm">
                      No deals found. <Link href="/portal/deals/new" className="text-brand-700 underline">Register your first deal</Link>
                    </td>
                  </tr>
                )
              : deals.map(deal => (
                  <tr key={deal.id} className="hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors">
                    <td className="px-4 py-3">
                      <Link href={`/portal/deals/${deal.id}`} className="font-medium text-brand-700 hover:underline">
                        {deal.dealName}
                      </Link>
                      <p className="text-xs text-muted-foreground">{deal.id.slice(0, 8).toUpperCase()}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p>{deal.prospectName}</p>
                      <p className="text-xs text-muted-foreground">{deal.prospectCountry}</p>
                    </td>
                    <td className="px-4 py-3 font-medium">{formatCurrency(deal.estimatedValueUsd)}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ${DEAL_STATUS_CLASS[deal.status]}`}>
                        {DEAL_STATUS_LABEL[deal.status]}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {format(new Date(deal.expectedCloseDate), 'MMM d, yyyy')}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {deal.assignedAm?.name ?? <span className="text-xs">Unassigned</span>}
                    </td>
                  </tr>
                ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
