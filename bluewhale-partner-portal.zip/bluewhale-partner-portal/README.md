# BlueWhale Stack Partner Portal

A full-stack partner portal built with **Next.js 14** (frontend) and **Fastify + Prisma** (backend), modelled after Microsoft Partner Network and AWS Partner Network.

---

## Architecture

```
bluewhale-partner-portal/
├── frontend/          # Next.js 14 + TypeScript + Tailwind + shadcn/ui
└── backend/           # Node.js + Fastify + Prisma + PostgreSQL
```

## Tech Stack

| Layer        | Technology                              |
|--------------|-----------------------------------------|
| Frontend     | Next.js 14, TypeScript, Tailwind CSS, shadcn/ui |
| State        | TanStack Query, Zustand                 |
| Charts       | Recharts                                |
| Backend      | Node.js, Fastify, Prisma ORM           |
| Database     | PostgreSQL (Supabase), Redis (Upstash)  |
| Auth         | Auth0 (SSO, MFA, SAML 2.0, RBAC)      |
| Realtime     | Socket.io                               |
| Email        | Resend                                  |
| File Storage | AWS S3                                  |
| Jobs         | BullMQ                                  |
| Hosting      | Vercel (FE) + Railway (BE)             |

---

## Quick Start

### 1. Clone & Install

```bash
# Frontend
cd frontend && npm install

# Backend
cd backend && npm install
```

### 2. Configure Environment

```bash
# Frontend
cp frontend/.env.local.example frontend/.env.local
# Fill in Auth0 credentials and API URL

# Backend
cp backend/.env.example backend/.env
# Fill in DATABASE_URL, REDIS_URL, AUTH0_DOMAIN, etc.
```

### 3. Database Setup

```bash
cd backend

# Run migrations
npm run db:migrate

# Seed with demo data
npm run db:seed
```

### 4. Start Development Servers

```bash
# Terminal 1 — Backend (port 4000)
cd backend && npm run dev

# Terminal 2 — Frontend (port 3000)
cd frontend && npm run dev
```

Visit: http://localhost:3000

---

## Auth0 Setup (5 minutes)

1. Create an Auth0 application (Single Page Application)
2. Create an Auth0 API with audience: `https://api.partnerportal.bluewhalestack.com`
3. Add to Auth0 API — Permissions:
   - `read:deals`, `write:deals`, `manage:partners`, `approve:discounts`
4. Create an Auth0 Action (Login flow) to add user role to token:

```javascript
exports.onExecutePostLogin = async (event, api) => {
  const namespace = 'https://partnerportal.bluewhalestack.com'
  const role = event.user.app_metadata?.role ?? 'partner_user'
  api.idToken.setCustomClaim(`${namespace}/role`, role)
  api.accessToken.setCustomClaim(`${namespace}/role`, role)
}
```

5. Copy credentials to `.env.local` (frontend) and `.env` (backend)

---

## Deploy to Production (Railway + Vercel)

### Backend → Railway

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
cd backend
railway init
railway up

# Add environment variables in Railway dashboard
# Add PostgreSQL and Redis plugins in Railway
```

### Frontend → Vercel

```bash
# Install Vercel CLI
npm install -g vercel

cd frontend
vercel --prod

# Set environment variables in Vercel dashboard
```

---

## User Roles

| Role               | Type     | Access                                      |
|--------------------|----------|---------------------------------------------|
| `partner_admin`    | External | Full partner org management                 |
| `partner_user`     | External | Submit deals, view discounts, training      |
| `partner_manager`  | Internal | Manage partner accounts, approve tiers      |
| `account_manager`  | Internal | Co-sell collaboration, deal workspaces      |
| `sales_rep`        | Internal | Deal queue review, deal acceptance          |
| `finance_approver` | Internal | Discount exception approvals                |
| `portal_admin`     | Internal | Full admin access, user management          |
| `executive`        | Internal | Read-only KPI dashboards                    |

---

## API Endpoints

| Method | Path                           | Description                  |
|--------|--------------------------------|------------------------------|
| POST   | /api/v1/auth/provision         | Provision user on first login|
| GET    | /api/v1/auth/me                | Current user + partner info  |
| POST   | /api/v1/partners/register      | Partner registration (public)|
| GET    | /api/v1/partners/me            | My partner profile           |
| GET    | /api/v1/partners/me/stats      | Dashboard stats              |
| GET    | /api/v1/partners/me/tier       | Tier progress                |
| POST   | /api/v1/deals                  | Register new deal            |
| GET    | /api/v1/deals                  | List deals (filtered)        |
| GET    | /api/v1/deals/:id              | Deal detail                  |
| PATCH  | /api/v1/deals/:id/status       | Update deal status           |
| POST   | /api/v1/discounts              | Request discount             |
| PATCH  | /api/v1/discounts/:id/approve  | Approve discount             |
| PATCH  | /api/v1/discounts/:id/reject   | Reject discount              |
| GET    | /api/v1/workspace/:dealId      | Workspace overview           |
| POST   | /api/v1/workspace/:dealId/messages | Post workspace message  |
| POST   | /api/v1/workspace/:dealId/tasks    | Create task             |
| GET    | /api/v1/notifications          | User notifications           |
| GET    | /api/v1/admin/dashboard        | Executive KPI dashboard      |

---

## Database Schema

12 tables covering the full partner lifecycle:
`Partner` → `User` → `Deal` → `DealAttachment` → `DealStatusHistory` → `Discount` → `WorkspaceMessage` → `WorkspaceTask` → `WorkspaceMilestone` → `TierApplication` → `PartnerDocument` → `Notification`

Run `npm run db:studio` to browse data visually.

---

## Project Status

- [x] BRD, FSD, User Persona documents
- [x] Frontend scaffold — Next.js 14 + TypeScript + Tailwind
- [x] Backend scaffold — Fastify + Prisma + PostgreSQL
- [x] Full data model (Prisma schema)
- [x] Auth0 JWT middleware with RBAC
- [x] Partner dashboard with stats, charts, activity feed
- [x] Deal registration form (multi-step with Zod validation)
- [x] Deals list with filters and search
- [x] Discount engine with tier ceiling enforcement
- [x] Co-sell workspace with Socket.io realtime
- [x] Internal sales/PM dashboard with deal queue
- [x] Email notifications via Resend
- [x] BullMQ job queues (email + deal expiry cron)
- [x] Database seed with realistic demo data
- [x] Next.js middleware for route protection
- [ ] Deal detail + workspace UI page
- [ ] Partner registration public page
- [ ] Training & certification module
- [ ] File upload (S3) integration
- [ ] Mobile-responsive polish
