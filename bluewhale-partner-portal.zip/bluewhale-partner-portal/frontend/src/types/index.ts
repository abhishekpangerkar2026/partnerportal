// ─── Enums ────────────────────────────────────────────────────────────────────

export type PartnerTier   = 'registered' | 'silver' | 'gold' | 'platinum'
export type PartnerStatus = 'pending' | 'active' | 'suspended' | 'inactive'

export type DealStatus =
  | 'submitted'
  | 'under_review'
  | 'accepted'
  | 'rejected'
  | 'in_progress'
  | 'won'
  | 'lost'
  | 'expired'

export type DiscountStatus = 'pending' | 'approved' | 'rejected' | 'counter_offered'

export type UserRole =
  | 'partner_admin'
  | 'partner_user'
  | 'partner_manager'
  | 'account_manager'
  | 'sales_rep'
  | 'finance_approver'
  | 'portal_admin'
  | 'executive'

// ─── Partner ──────────────────────────────────────────────────────────────────

export interface Partner {
  id:                 string
  companyName:        string
  tradingName?:       string
  registrationNumber: string
  countryCode:        string
  website:            string
  industry:           string
  tier:               PartnerTier
  status:             PartnerStatus
  assignedPmId?:      string
  assignedPm?:        User
  createdAt:          string
  tierReviewDate:     string
  annualRevenue?:     number
  nextTierTarget?:    number
}

// ─── User ─────────────────────────────────────────────────────────────────────

export interface User {
  id:         string
  name:       string
  email:      string
  role:       UserRole
  partnerId?: string
  avatarUrl?: string
  createdAt:  string
}

// ─── Deal ─────────────────────────────────────────────────────────────────────

export interface Deal {
  id:                 string
  dealName:           string
  partnerId:          string
  partner?:           Partner
  prospectName:       string
  prospectWebsite?:   string
  prospectCountry:    string
  prospectIndustry:   string
  contactName:        string
  contactEmail:       string
  contactPhone:       string
  products:           string[]
  estimatedValueUsd:  number
  status:             DealStatus
  dealSource:         string
  description:        string
  incumbent?:         string
  expectedCloseDate:  string
  expiryDate:         string
  assignedAmId?:      string
  assignedAm?:        User
  rejectionReason?:   string
  wonLostReason?:     string
  attachments:        DealAttachment[]
  createdAt:          string
  updatedAt:          string
}

export interface DealAttachment {
  id:          string
  fileName:    string
  fileUrl:     string
  fileType:    string
  uploadedAt:  string
  uploadedBy:  string
}

// ─── Discount ─────────────────────────────────────────────────────────────────

export interface Discount {
  id:              string
  dealId:          string
  deal?:           Deal
  partnerId:       string
  product:         string
  listPriceUsd:    number
  requestedPct:    number
  approvedPct?:    number
  status:          DiscountStatus
  justification:   string
  approvedById?:   string
  approvedBy?:     User
  approvedAt?:     string
  rejectionReason?:string
  counterOffer?:   number
  authLetterUrl?:  string
  createdAt:       string
}

// ─── Workspace ────────────────────────────────────────────────────────────────

export interface WorkspaceMessage {
  id:          string
  dealId:      string
  authorId:    string
  author:      User
  content:     string
  isInternal:  boolean
  attachments: string[]
  createdAt:   string
}

export interface WorkspaceTask {
  id:          string
  dealId:      string
  title:       string
  description?:string
  assigneeId:  string
  assignee:    User
  dueDate:     string
  priority:    'low' | 'medium' | 'high'
  status:      'open' | 'in_progress' | 'blocked' | 'completed'
  createdAt:   string
}

export interface WorkspaceMilestone {
  id:          string
  dealId:      string
  label:       string
  order:       number
  completedAt?:string
  completedBy?:string
}

// ─── Notification ─────────────────────────────────────────────────────────────

export interface Notification {
  id:        string
  userId:    string
  type:      string
  title:     string
  body:      string
  readAt?:   string
  metadata?: Record<string, unknown>
  createdAt: string
}

// ─── API response wrappers ────────────────────────────────────────────────────

export interface PaginatedResponse<T> {
  data:       T[]
  total:      number
  page:       number
  pageSize:   number
  totalPages: number
}

export interface ApiError {
  statusCode: number
  error:      string
  message:    string
}
