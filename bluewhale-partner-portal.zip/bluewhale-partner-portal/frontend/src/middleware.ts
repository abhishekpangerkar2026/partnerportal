import { withMiddlewareAuthRequired, getSession } from '@auth0/nextjs-auth0/edge'
import { NextResponse }                           from 'next/server'
import type { NextRequest }                       from 'next/server'

const INTERNAL_ROLES = [
  'partner_manager',
  'account_manager',
  'sales_rep',
  'finance_approver',
  'portal_admin',
  'executive',
]

const PARTNER_ROLES = ['partner_admin', 'partner_user']

export default withMiddlewareAuthRequired(async function middleware(req: NextRequest) {
  const res     = NextResponse.next()
  const session = await getSession(req, res)
  const user    = session?.user
  const role    = (user?.['https://partnerportal.bluewhalestack.com/role'] ?? '') as string

  const pathname = req.nextUrl.pathname

  // /portal/* → partner roles only
  if (pathname.startsWith('/portal')) {
    if (!PARTNER_ROLES.includes(role)) {
      // Internal users who hit /portal get redirected to internal dashboard
      if (INTERNAL_ROLES.includes(role)) {
        return NextResponse.redirect(new URL('/internal/dashboard', req.url))
      }
      return NextResponse.redirect(new URL('/unauthorized', req.url))
    }
  }

  // /internal/* → internal roles only
  if (pathname.startsWith('/internal')) {
    if (!INTERNAL_ROLES.includes(role)) {
      return NextResponse.redirect(new URL('/portal/dashboard', req.url))
    }
  }

  return res
})

export const config = {
  matcher: [
    '/portal/:path*',
    '/internal/:path*',
  ],
}
