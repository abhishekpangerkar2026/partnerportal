import axios from 'axios'

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL + '/api/v1',
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
})

// ── Request: attach Auth0 token ──────────────────────────────────────────────
api.interceptors.request.use(async (config) => {
  // Token is forwarded server-side via cookie; client-side we fetch from Auth0
  if (typeof window !== 'undefined') {
    try {
      const res = await fetch('/api/auth/token')
      if (res.ok) {
        const { accessToken } = await res.json()
        if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`
      }
    } catch { /* silently skip — cookie auth still applies */ }
  }
  return config
})

// ── Response: normalise errors ───────────────────────────────────────────────
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      window.location.href = '/api/auth/login'
    }
    return Promise.reject(error)
  }
)
