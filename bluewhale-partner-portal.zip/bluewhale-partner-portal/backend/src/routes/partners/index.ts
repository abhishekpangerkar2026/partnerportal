import type { FastifyInstance } from 'fastify'
import { z }                   from 'zod'
import { prisma }              from '../config/db'
import { authenticate, requireRoles } from '../middleware/auth'
import { NotificationService } from '../services/NotificationService'
import { EmailService }        from '../services/EmailService'
import { DealService }         from '../services/DealService'
import type { PartnerTier }    from '@prisma/client'

const registerSchema = z.object({
  companyName:        z.string().min(2),
  tradingName:        z.string().optional(),
  registrationNumber: z.string().min(1),
  countryCode:        z.string().length(2),
  website:            z.string().url(),
  industry:           z.string().min(1),
  // Primary contact (becomes the PARTNER_ADMIN user)
  contactName:        z.string().min(2),
  contactEmail:       z.string().email(),
  contactPhone:       z.string().min(7),
  // Partnership interest
  partnershipTypes:   z.array(z.string()).min(1),
  productsOfInterest: z.array(z.string()).min(1),
  annualRevenueRange: z.string(),
  howDidYouHear:      z.string().optional(),
})

const tierApplicationSchema = z.object({
  requestedTier: z.enum(['SILVER', 'GOLD', 'PLATINUM']),
  notes:         z.string().optional(),
})

export default async function partnerRoutes(fastify: FastifyInstance) {

  // ── POST /partners/register  (public — unauthenticated) ───────────────────
  fastify.post('/register', async (req, reply) => {
    const body = registerSchema.parse(req.body)

    // Duplicate check on company registration number
    const existing = await prisma.partner.findFirst({
      where: { registrationNumber: body.registrationNumber },
    })
    if (existing) {
      return reply.code(409).send({
        error:   'Conflict',
        message: 'A partner with this registration number already exists',
      })
    }

    // Auto-assign a partner manager (round-robin by load)
    const pm = await prisma.user.findFirst({
      where:   { role: 'PARTNER_MANAGER' },
      orderBy: { managedPartners: { _count: 'asc' } },
    })

    const partner = await prisma.partner.create({
      data: {
        companyName:        body.companyName,
        tradingName:        body.tradingName,
        registrationNumber: body.registrationNumber,
        countryCode:        body.countryCode,
        website:            body.website,
        industry:           body.industry,
        status:             'PENDING',
        tier:               'REGISTERED',
        assignedPmId:       pm?.id,
      },
    })

    // Notify PM about new registration
    if (pm) {
      await NotificationService.notifyUser({
        userId:   pm.id,
        type:     'NEW_PARTNER_REGISTRATION',
        title:    'New Partner Registration',
        body:     `${body.companyName} has submitted a partner registration and is pending your review.`,
        metadata: { partnerId: partner.id },
      })
    }

    return reply.code(201).send({
      message:   'Registration submitted successfully. You will be notified within 3 business days.',
      partnerId: partner.id,
    })
  })

  // ── GET /partners/me  ─────────────────────────────────────────────────────
  fastify.get('/me', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    if (!jwtUser!.partnerId) {
      return reply.code(404).send({ error: 'Not Found', message: 'No partner profile found' })
    }

    const partner = await prisma.partner.findUnique({
      where:   { id: jwtUser!.partnerId },
      include: {
        assignedPm: { select: { id: true, name: true, email: true, avatarUrl: true } },
        users:      { select: { id: true, name: true, email: true, role: true, avatarUrl: true } },
        documents:  { orderBy: { createdAt: 'desc' } },
      },
    })

    return reply.send(partner)
  })

  // ── GET /partners/me/stats  ───────────────────────────────────────────────
  fastify.get('/me/stats', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    if (!jwtUser!.partnerId) return reply.code(403).send({ error: 'Forbidden' })
    const stats = await DealService.getStats(jwtUser!.partnerId)
    return reply.send(stats)
  })

  // ── GET /partners/me/tier  ────────────────────────────────────────────────
  fastify.get('/me/tier', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    if (!jwtUser!.partnerId) return reply.code(403).send({ error: 'Forbidden' })

    const partner = await prisma.partner.findUnique({
      where:  { id: jwtUser!.partnerId },
      select: { tier: true, annualRevenue: true },
    })

    const TIER_THRESHOLDS: Record<string, number> = {
      REGISTERED: 50_000,
      SILVER:     250_000,
      GOLD:       1_000_000,
      PLATINUM:   Infinity,
    }
    const NEXT_TIER: Record<string, string | null> = {
      REGISTERED: 'SILVER',
      SILVER:     'GOLD',
      GOLD:       'PLATINUM',
      PLATINUM:   null,
    }

    const currentTier = partner?.tier ?? 'REGISTERED'
    const nextTier    = NEXT_TIER[currentTier]

    return reply.send({
      tier:            currentTier,
      nextTier,
      annualRevenue:   Number(partner?.annualRevenue ?? 0),
      nextTierTarget:  nextTier ? TIER_THRESHOLDS[currentTier] : null,
    })
  })

  // ── GET /partners/me/pipeline-chart  ─────────────────────────────────────
  fastify.get('/me/pipeline-chart', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    if (!jwtUser!.partnerId) return reply.code(403).send({ error: 'Forbidden' })
    const data = await DealService.getPipelineChart(jwtUser!.partnerId)
    return reply.send(data)
  })

  // ── GET /partners/me/activity  ────────────────────────────────────────────
  fastify.get('/me/activity', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    if (!jwtUser!.partnerId) return reply.code(403).send({ error: 'Forbidden' })

    const notifications = await prisma.notification.findMany({
      where:   { user: { partnerId: jwtUser!.partnerId } },
      orderBy: { createdAt: 'desc' },
      take:    10,
    })

    return reply.send(notifications.map(n => ({
      id:      n.id,
      type:    n.type.toLowerCase(),
      message: n.body,
      time:    n.createdAt,
    })))
  })

  // ── POST /partners/me/tier/apply  ─────────────────────────────────────────
  fastify.post('/me/tier/apply', { preHandler: authenticate }, async (req, reply) => {
    const { jwtUser } = req
    if (!jwtUser!.partnerId) return reply.code(403).send({ error: 'Forbidden' })

    const body    = tierApplicationSchema.parse(req.body)
    const partner = await prisma.partner.findUnique({
      where:  { id: jwtUser!.partnerId },
      select: { tier: true, assignedPmId: true },
    })
    if (!partner) return reply.code(404).send({ error: 'Not Found' })

    const application = await prisma.tierApplication.create({
      data: {
        partnerId:     jwtUser!.partnerId,
        requestedTier: body.requestedTier as PartnerTier,
        currentTier:   partner.tier,
        notes:         body.notes,
      },
    })

    // Notify PM
    if (partner.assignedPmId) {
      await NotificationService.notifyUser({
        userId:   partner.assignedPmId,
        type:     'TIER_APPLICATION',
        title:    'Tier Upgrade Application',
        body:     `A partner has applied for ${body.requestedTier} tier status.`,
        metadata: { applicationId: application.id, partnerId: jwtUser!.partnerId },
      })
    }

    return reply.code(201).send(application)
  })

  // ── GET /partners  (internal — PM/Admin) ──────────────────────────────────
  fastify.get(
    '/',
    { preHandler: requireRoles(['PARTNER_MANAGER', 'PORTAL_ADMIN', 'EXECUTIVE', 'SALES_REP']) },
    async (req, reply) => {
      const q = req.query as Record<string, string>
      const page     = Math.max(1, Number(q.page ?? 1))
      const pageSize = Math.min(50, Number(q.pageSize ?? 20))
      const skip     = (page - 1) * pageSize

      const where: Record<string, unknown> = {}
      if (q.status)       where.status = q.status
      if (q.tier)         where.tier   = q.tier
      if (q.assignedPmId) where.assignedPmId = q.assignedPmId
      if (q.search) {
        where.OR = [
          { companyName: { contains: q.search, mode: 'insensitive' } },
        ]
      }

      const [data, total] = await Promise.all([
        prisma.partner.findMany({
          where,
          include: {
            assignedPm: { select: { id: true, name: true } },
            _count:     { select: { deals: true, users: true } },
          },
          orderBy: { createdAt: 'desc' },
          skip,
          take: pageSize,
        }),
        prisma.partner.count({ where }),
      ])

      return reply.send({ data, total, page, pageSize, totalPages: Math.ceil(total / pageSize) })
    }
  )

  // ── PATCH /partners/:id/status  (PM/Admin) ────────────────────────────────
  fastify.patch(
    '/:id/status',
    { preHandler: requireRoles(['PARTNER_MANAGER', 'PORTAL_ADMIN']) },
    async (req, reply) => {
      const { id }     = req.params as { id: string }
      const { status } = req.body as { status: 'ACTIVE' | 'SUSPENDED' | 'INACTIVE' }

      const partner = await prisma.partner.update({
        where: { id },
        data:  { status },
        select: { companyName: true, users: { select: { email: true } } },
      })

      if (status === 'ACTIVE') {
        for (const user of partner.users) {
          await EmailService.partnerApproved({
            to:          user.email,
            partnerName: partner.companyName,
            loginUrl:    `${process.env.FRONTEND_URL}/api/auth/login`,
          })
        }
      }

      return reply.send({ message: `Partner status updated to ${status}` })
    }
  )
}
