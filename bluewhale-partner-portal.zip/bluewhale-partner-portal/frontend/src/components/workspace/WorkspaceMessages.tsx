'use client'

import { useState, useEffect, useRef } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useUser }  from '@auth0/nextjs-auth0/client'
import { api }      from '@/lib/api'
import { initials } from '@/lib/utils'
import { formatDistanceToNow } from 'date-fns'
import { Send, Lock }          from 'lucide-react'
import { io, Socket }          from 'socket.io-client'
import type { WorkspaceMessage } from '@/types'

interface Props {
  dealId:          string
  initialMessages: WorkspaceMessage[]
}

export function WorkspaceMessages({ dealId, initialMessages }: Props) {
  const { user }        = useUser()
  const queryClient     = useQueryClient()
  const bottomRef       = useRef<HTMLDivElement>(null)
  const [content, setContent]       = useState('')
  const [isInternal, setIsInternal] = useState(false)
  const socketRef       = useRef<Socket | null>(null)

  // Determine if current user is internal (has no partnerId in their namespace claim)
  const isInternalUser = !(user?.['https://partnerportal.bluewhalestack.com/partnerId'])

  const { data: messages = initialMessages } = useQuery<WorkspaceMessage[]>({
    queryKey:    ['workspace-messages', dealId],
    queryFn:     () => api.get(`/workspace/${dealId}/messages`).then(r => r.data),
    initialData: initialMessages,
  })

  // Socket.io — subscribe to live message events
  useEffect(() => {
    const socket = io(process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000', {
      withCredentials: true,
    })
    socketRef.current = socket
    socket.emit('join:deal', dealId)

    socket.on('workspace:message', (msg: WorkspaceMessage) => {
      queryClient.setQueryData<WorkspaceMessage[]>(
        ['workspace-messages', dealId],
        (prev = []) => [...prev, msg]
      )
    })

    return () => {
      socket.emit('leave:deal', dealId)
      socket.disconnect()
    }
  }, [dealId, queryClient])

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMutation = useMutation({
    mutationFn: () =>
      api.post(`/workspace/${dealId}/messages`, { content, isInternal }).then(r => r.data),
    onSuccess: () => {
      setContent('')
      queryClient.invalidateQueries({ queryKey: ['workspace-messages', dealId] })
    },
  })

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey) && content.trim()) {
      sendMutation.mutate()
    }
  }

  return (
    <div className="stat-card flex flex-col" style={{ height: '480px' }}>
      <h3 className="mb-3 text-sm font-semibold border-b pb-2">Messages</h3>

      {/* Message thread */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-1">
        {messages.map(msg => {
          const isMine = msg.author.id === user?.sub
          return (
            <div
              key={msg.id}
              className={`flex gap-2.5 ${isMine ? 'flex-row-reverse' : 'flex-row'} ${
                msg.isInternal ? 'opacity-80' : ''
              }`}
            >
              {/* Avatar */}
              <div className="flex-shrink-0 flex h-7 w-7 items-center justify-center rounded-full bg-brand-100 text-[10px] font-semibold text-brand-700 mt-1">
                {initials(msg.author.name)}
              </div>

              {/* Bubble */}
              <div className={`max-w-[75%] ${isMine ? 'items-end' : 'items-start'} flex flex-col gap-0.5`}>
                {/* Internal badge */}
                {msg.isInternal && (
                  <div className="flex items-center gap-1 text-[10px] text-amber-600">
                    <Lock className="h-2.5 w-2.5" /> Internal note
                  </div>
                )}
                <div
                  className={`rounded-2xl px-3 py-2 text-sm leading-relaxed ${
                    msg.isInternal
                      ? 'border border-amber-200 bg-amber-50 text-amber-900 dark:bg-amber-900/20 dark:text-amber-200'
                      : isMine
                      ? 'bg-brand-700 text-white'
                      : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                  }`}
                >
                  {msg.content}
                </div>
                <p className="text-[10px] text-muted-foreground">
                  {msg.author.name} · {formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true })}
                </p>
              </div>
            </div>
          )
        })}
        <div ref={bottomRef} />
      </div>

      {/* Composer */}
      <div className="mt-3 border-t pt-3 space-y-2">
        {isInternalUser && (
          <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer select-none">
            <input
              type="checkbox"
              checked={isInternal}
              onChange={e => setIsInternal(e.target.checked)}
              className="rounded"
            />
            <Lock className="h-3 w-3" /> Internal note (hidden from partner)
          </label>
        )}
        <div className={`flex gap-2 rounded-lg border p-2 ${isInternal ? 'border-amber-300 bg-amber-50 dark:bg-amber-900/20' : ''}`}>
          <textarea
            value={content}
            onChange={e => setContent(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={2}
            className="flex-1 resize-none bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            placeholder={isInternal ? 'Internal note (not visible to partner)…' : 'Write a message… (Cmd+Enter to send)'}
          />
          <button
            onClick={() => content.trim() && sendMutation.mutate()}
            disabled={!content.trim() || sendMutation.isPending}
            className="self-end rounded-lg bg-brand-700 p-2 text-white hover:bg-brand-800 disabled:opacity-40 transition-colors"
          >
            <Send className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  )
}
