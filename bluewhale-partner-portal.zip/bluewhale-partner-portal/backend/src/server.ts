import 'dotenv/config'
import Fastify from 'fastify'
import cors from '@fastify/cors'
import helmet from '@fastify/helmet'
import rateLimit from '@fastify/rate-limit'
import multipart from '@fastify/multipart'
import { Server } from 'socket.io'
import { createServer } from 'http'

import { prisma }          from './config/db'
import { redis }           from './config/redis'
import { authPlugin }      from './middleware/auth'
import { errorHandler }    from './middleware/errorHandler'

import authRoutes          from './routes/auth'
import partnerRoutes       from './routes/partners'
import dealRoutes          from './routes/deals'
import discountRoutes      from './routes/discounts'
import workspaceRoutes     from './routes/workspace'
import notificationRoutes  from './routes/notifications'
import adminRoutes         from './routes/admin'

const PORT = Number(process.env.PORT ?? 4000)

async function bootstrap() {
  const app = Fastify({
    logger: {
      transport: process.env.NODE_ENV === 'development'
        ? { target: 'pino-pretty', options: { colorize: true } }
        : undefined,
    },
  })

  // ── Security ────────────────────────────────────────────────────────────────
  await app.register(helmet, { contentSecurityPolicy: false })
  await app.register(cors, {
    origin: process.env.FRONTEND_URL,
    credentials: true,
  })
  await app.register(rateLimit, {
    global: true,
    max: 200,
    timeWindow: '1 minute',
    redis,
  })

  // ── Multipart (file uploads) ─────────────────────────────────────────────
  await app.register(multipart, {
    limits: { fileSize: 25 * 1024 * 1024 }, // 25 MB
  })

  // ── Auth ────────────────────────────────────────────────────────────────────
  await app.register(authPlugin)

  // ── Routes ──────────────────────────────────────────────────────────────────
  await app.register(authRoutes,         { prefix: '/api/v1/auth' })
  await app.register(partnerRoutes,      { prefix: '/api/v1/partners' })
  await app.register(dealRoutes,         { prefix: '/api/v1/deals' })
  await app.register(discountRoutes,     { prefix: '/api/v1/discounts' })
  await app.register(workspaceRoutes,    { prefix: '/api/v1/workspace' })
  await app.register(notificationRoutes, { prefix: '/api/v1/notifications' })
  await app.register(adminRoutes,        { prefix: '/api/v1/admin' })

  // ── Health check ────────────────────────────────────────────────────────────
  app.get('/health', async () => ({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version,
  }))

  // ── Error handler ────────────────────────────────────────────────────────────
  app.setErrorHandler(errorHandler)

  // ── Socket.io (co-sell workspace real-time) ──────────────────────────────────
  const httpServer = createServer(app.server)
  const io = new Server(httpServer, {
    cors: { origin: process.env.FRONTEND_URL, credentials: true },
  })

  io.on('connection', (socket) => {
    app.log.info(`Socket connected: ${socket.id}`)

    socket.on('join:deal', (dealId: string) => {
      socket.join(`deal:${dealId}`)
    })

    socket.on('leave:deal', (dealId: string) => {
      socket.leave(`deal:${dealId}`)
    })

    socket.on('disconnect', () => {
      app.log.info(`Socket disconnected: ${socket.id}`)
    })
  })

  // Attach io to app so routes can use it
  app.decorate('io', io)

  // ── Start ────────────────────────────────────────────────────────────────────
  try {
    await app.ready()
    httpServer.listen(PORT, '0.0.0.0')
    app.log.info(`Server running on http://localhost:${PORT}`)
  } catch (err) {
    app.log.error(err)
    process.exit(1)
  }
}

// ── Graceful shutdown ─────────────────────────────────────────────────────────
process.on('SIGTERM', async () => {
  await prisma.$disconnect()
  redis.disconnect()
  process.exit(0)
})

bootstrap()
