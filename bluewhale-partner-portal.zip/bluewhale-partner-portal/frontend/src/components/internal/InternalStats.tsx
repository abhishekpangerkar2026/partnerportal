'use client'

import { useQuery }   from '@tanstack/react-query'
import { api }        from '@/lib/api'
import { Building2, FileText, TrendingUp, Clock } from 'lucide-react'

export function InternalStats() {
  const { data, isLoading } = useQuery({
    queryKey: ['admin-dashboard'],
    queryFn:  () => api.get('/admin/dashboard').then(r => r.data),
  })

  const stats = [
    {
      label:    'Active Partners',
      value:    isLoading ? '—' : data?.activePartners ?? 0,
      sub:      `${data?.totalPartners ?? 0} total`,
      icon:     Building2,
      color:    'text-blue-600 bg-blue-50',
    },
    {
      label:    'Open Pipeline',
      value:    isLoading ? '—' : `$${((data?.pipelineValue ?? 0) / 1_000_000).toFixed(1)}M`,
      sub:      `${data?.totalDeals ?? 0} total deals`,
      icon:     TrendingUp,
      color:    'text-emerald-600 bg-emerald-50',
    },
    {
      label:    'Win Rate',
      value:    isLoading ? '—' : `${data?.winRate ?? 0}%`,
      sub:      `${data?.wonDeals ?? 0} deals won`,
      icon:     FileText,
      color:    'text-purple-600 bg-purple-50',
    },
    {
      label:    'Pending Discounts',
      value:    isLoading ? '—' : data?.pendingDiscounts ?? 0,
      sub:      'Awaiting approval',
      icon:     Clock,
      color:    'text-amber-600 bg-amber-50',
    },
  ]

  return (
    <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
      {stats.map(s => {
        const Icon = s.icon
        return (
          <div key={s.label} className="stat-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">{s.label}</p>
                <p className="mt-1 text-2xl font-semibold">{s.value}</p>
              </div>
              <div className={`rounded-lg p-2 ${s.color}`}>
                <Icon className="h-4 w-4" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{s.sub}</p>
          </div>
        )
      })}
    </div>
  )
}
