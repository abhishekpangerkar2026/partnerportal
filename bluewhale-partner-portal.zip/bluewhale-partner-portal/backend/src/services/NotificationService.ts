import { prisma }       from '../config/db'
import { emailQueue }   from '../jobs/queues'
import type { UserRole } from '@prisma/client'

interface NotifyInput {
  type:      string
  title:     string
  body:      string
  metadata?: Record<string, unknown>
}

interface NotifyPartnerInput extends NotifyInput {
  partnerId: string
}

interface NotifyUserInput extends NotifyInput {
  userId: string
}

const SALES_ROLES: UserRole[] = ['SALES_REP', 'PARTNER_MANAGER', 'PORTAL_ADMIN']

export const NotificationService = {

  async notifyUser({ userId, type, title, body, metadata }: NotifyUserInput) {
    const notification = await prisma.notification.create({
      data: { userId, type, title, body, metadata },
    })

    // Queue email for this notification
    await emailQueue.add('send-notification-email', {
      notificationId: notification.id,
      userId,
      type,
      title,
      body,
    }, { attempts: 3, backoff: { type: 'exponential', delay: 5000 } })

    return notification
  },

  async notifyPartner({ partnerId, type, title, body, metadata }: NotifyPartnerInput) {
    // Notify all admin users of the partner org
    const users = await prisma.user.findMany({
      where: { partnerId, role: { in: ['PARTNER_ADMIN', 'PARTNER_USER'] } },
      select: { id: true },
    })

    await Promise.all(
      users.map(u =>
        NotificationService.notifyUser({ userId: u.id, type, title, body, metadata })
      )
    )
  },

  async notifySalesTeam({ type, title, body, metadata }: NotifyInput) {
    const users = await prisma.user.findMany({
      where:  { role: { in: SALES_ROLES } },
      select: { id: true },
    })

    await Promise.all(
      users.map(u =>
        NotificationService.notifyUser({ userId: u.id, type, title, body, metadata })
      )
    )
  },

  async notifyUser_byRole({ roles, type, title, body, metadata }: NotifyInput & { roles: UserRole[] }) {
    const users = await prisma.user.findMany({
      where:  { role: { in: roles } },
      select: { id: true },
    })

    await Promise.all(
      users.map(u =>
        NotificationService.notifyUser({ userId: u.id, type, title, body, metadata })
      )
    )
  },

  async markRead(notificationId: string, userId: string) {
    return prisma.notification.updateMany({
      where: { id: notificationId, userId },
      data:  { readAt: new Date() },
    })
  },

  async markAllRead(userId: string) {
    return prisma.notification.updateMany({
      where: { userId, readAt: null },
      data:  { readAt: new Date() },
    })
  },

  async getUnreadCount(userId: string) {
    return prisma.notification.count({
      where: { userId, readAt: null },
    })
  },

  async list(userId: string, page = 1, pageSize = 20) {
    const skip = (page - 1) * pageSize
    const [data, total] = await Promise.all([
      prisma.notification.findMany({
        where:   { userId },
        orderBy: { createdAt: 'desc' },
        skip,
        take: pageSize,
      }),
      prisma.notification.count({ where: { userId } }),
    ])
    return { data, total, page, pageSize }
  },
}
