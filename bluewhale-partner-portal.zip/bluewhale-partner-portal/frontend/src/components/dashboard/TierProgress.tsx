'use client'

import { useQuery } from '@tanstack/react-query'
import { api } from '@/lib/api'

const TIERS = ['Registered', 'Silver', 'Gold', 'Platinum']
const TIER_COLORS: Record<string, string> = {
  Registered: 'bg-slate-400',
  Silver:     'bg-slate-500',
  Gold:       'bg-amber-400',
  Platinum:   'bg-brand-700',
}

export function TierProgress() {
  const { data } = useQuery({
    queryKey: ['partner-tier'],
    queryFn: () => api.get('/partners/me/tier').then(r => r.data),
  })

  const currentTier  = data?.tier ?? 'Silver'
  const nextTier     = data?.nextTier ?? 'Gold'
  const revenue      = data?.annualRevenue ?? 120000
  const target       = data?.nextTierTarget ?? 250000
  const pct          = Math.min(Math.round((revenue / target) * 100), 100)

  return (
    <div className="stat-card space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Partnership Tier</h3>
        <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold text-white ${TIER_COLORS[currentTier] ?? 'bg-slate-400'}`}>
          {currentTier}
        </span>
      </div>

      {/* Tier ladder */}
      <div className="flex items-center gap-1">
        {TIERS.map((tier, i) => {
          const active = tier === currentTier
          const done   = TIERS.indexOf(currentTier) > i
          return (
            <div key={tier} className="flex flex-1 flex-col items-center gap-1">
              <div className={`h-1.5 w-full rounded-full ${done || active ? TIER_COLORS[tier] : 'bg-gray-200'}`} />
              <span className={`text-[10px] ${active ? 'font-semibold text-brand-700' : 'text-muted-foreground'}`}>
                {tier}
              </span>
            </div>
          )
        })}
      </div>

      {/* Progress to next */}
      {nextTier && (
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Progress to {nextTier}</span>
            <span>{pct}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-gray-100">
            <div
              className="h-full rounded-full bg-brand-700 transition-all duration-700"
              style={{ width: `${pct}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-muted-foreground">
            <span>${revenue.toLocaleString()} revenue</span>
            <span>${target.toLocaleString()} target</span>
          </div>
        </div>
      )}
    </div>
  )
}
