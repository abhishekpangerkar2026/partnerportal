'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useRouter } from 'next/navigation'
import { api } from '@/lib/api'

const dealSchema = z.object({
  // Prospect
  prospectName:     z.string().min(2, 'Company name required'),
  prospectWebsite:  z.string().url('Enter a valid URL').optional().or(z.literal('')),
  prospectCountry:  z.string().min(1, 'Country required'),
  prospectIndustry: z.string().min(1, 'Industry required'),
  contactName:      z.string().min(2, 'Contact name required'),
  contactEmail:     z.string().email('Valid email required'),
  contactPhone:     z.string().min(7, 'Phone required'),
  // Deal
  dealName:         z.string().min(3, 'Deal name required'),
  products:         z.array(z.string()).min(1, 'Select at least one product'),
  estimatedValue:   z.number({ invalid_type_error: 'Enter a number' }).positive('Must be positive'),
  dealSource:       z.string().min(1, 'Select deal source'),
  expectedCloseDate:z.string().min(1, 'Close date required'),
  description:      z.string().min(100, 'Minimum 100 characters').max(2000),
  incumbent:        z.string().optional(),
})

type DealForm = z.infer<typeof dealSchema>

const PRODUCTS = [
  'BW Cloud Platform', 'BW Data Suite', 'BW Security Hub',
  'BW Analytics Pro', 'BW DevOps Tools', 'BW AI Services',
]

const INDUSTRIES = [
  'Technology', 'Healthcare', 'Finance', 'Retail',
  'Manufacturing', 'Education', 'Government', 'Other',
]

const SOURCES = [
  'Inbound Referral', 'Outbound Prospecting', 'Event / Conference',
  'Existing Customer Expansion', 'Social Media', 'Other',
]

export default function NewDealPage() {
  const router = useRouter()
  const queryClient = useQueryClient()

  const { register, handleSubmit, watch, setValue, formState: { errors, isSubmitting } } = useForm<DealForm>({
    resolver: zodResolver(dealSchema),
    defaultValues: { products: [] },
  })

  const selectedProducts = watch('products') ?? []

  const mutation = useMutation({
    mutationFn: (data: DealForm) => api.post('/deals', data).then(r => r.data),
    onSuccess: (deal) => {
      queryClient.invalidateQueries({ queryKey: ['deals'] })
      router.push(`/portal/deals/${deal.id}`)
    },
  })

  function toggleProduct(p: string) {
    const next = selectedProducts.includes(p)
      ? selectedProducts.filter(x => x !== p)
      : [...selectedProducts, p]
    setValue('products', next)
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold">Register New Deal</h1>
        <p className="text-sm text-muted-foreground">Complete all sections to protect your opportunity</p>
      </div>

      <form onSubmit={handleSubmit((d) => mutation.mutate(d))} className="space-y-6">

        {/* Section A — Prospect */}
        <section className="stat-card space-y-4">
          <h2 className="text-sm font-semibold text-brand-700 border-b pb-2">A. Prospect Information</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Company Name *</label>
              <input {...register('prospectName')} className="input" placeholder="Acme Corporation" />
              {errors.prospectName && <p className="error">{errors.prospectName.message}</p>}
            </div>
            <div>
              <label className="label">Website</label>
              <input {...register('prospectWebsite')} className="input" placeholder="https://acme.com" />
              {errors.prospectWebsite && <p className="error">{errors.prospectWebsite.message}</p>}
            </div>
            <div>
              <label className="label">Country *</label>
              <input {...register('prospectCountry')} className="input" placeholder="United States" />
              {errors.prospectCountry && <p className="error">{errors.prospectCountry.message}</p>}
            </div>
            <div>
              <label className="label">Industry *</label>
              <select {...register('prospectIndustry')} className="input">
                <option value="">Select industry</option>
                {INDUSTRIES.map(i => <option key={i} value={i}>{i}</option>)}
              </select>
              {errors.prospectIndustry && <p className="error">{errors.prospectIndustry.message}</p>}
            </div>
            <div>
              <label className="label">Contact Name *</label>
              <input {...register('contactName')} className="input" placeholder="John Smith" />
              {errors.contactName && <p className="error">{errors.contactName.message}</p>}
            </div>
            <div>
              <label className="label">Contact Email *</label>
              <input {...register('contactEmail')} className="input" type="email" placeholder="john@acme.com" />
              {errors.contactEmail && <p className="error">{errors.contactEmail.message}</p>}
            </div>
            <div>
              <label className="label">Contact Phone *</label>
              <input {...register('contactPhone')} className="input" placeholder="+1 415 555 0100" />
              {errors.contactPhone && <p className="error">{errors.contactPhone.message}</p>}
            </div>
          </div>
        </section>

        {/* Section B — Deal Details */}
        <section className="stat-card space-y-4">
          <h2 className="text-sm font-semibold text-brand-700 border-b pb-2">B. Deal Details</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="label">Deal Name *</label>
              <input {...register('dealName')} className="input" placeholder="Acme Corp – Cloud Platform – 2025" />
              {errors.dealName && <p className="error">{errors.dealName.message}</p>}
            </div>
            <div>
              <label className="label">Estimated Value (USD) *</label>
              <input
                {...register('estimatedValue', { valueAsNumber: true })}
                className="input" type="number" placeholder="50000"
              />
              {errors.estimatedValue && <p className="error">{errors.estimatedValue.message}</p>}
            </div>
            <div>
              <label className="label">Expected Close Date *</label>
              <input {...register('expectedCloseDate')} className="input" type="date" />
              {errors.expectedCloseDate && <p className="error">{errors.expectedCloseDate.message}</p>}
            </div>
            <div>
              <label className="label">Deal Source *</label>
              <select {...register('dealSource')} className="input">
                <option value="">Select source</option>
                {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              {errors.dealSource && <p className="error">{errors.dealSource.message}</p>}
            </div>
            <div>
              <label className="label">Current Incumbent</label>
              <input {...register('incumbent')} className="input" placeholder="Competitor name (optional)" />
            </div>
          </div>

          {/* Products */}
          <div>
            <label className="label">Products / Solutions *</label>
            <div className="flex flex-wrap gap-2">
              {PRODUCTS.map(p => (
                <button
                  key={p} type="button"
                  onClick={() => toggleProduct(p)}
                  className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                    selectedProducts.includes(p)
                      ? 'border-brand-700 bg-brand-700 text-white'
                      : 'border-gray-200 text-gray-600 hover:border-brand-300'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
            {errors.products && <p className="error">{errors.products.message}</p>}
          </div>

          {/* Description */}
          <div>
            <label className="label">Deal Description * <span className="text-muted-foreground font-normal">(min 100 chars)</span></label>
            <textarea
              {...register('description')}
              className="input min-h-[100px] resize-none"
              placeholder="Describe the opportunity, customer pain points, and why BlueWhale Stack is the right fit..."
            />
            {errors.description && <p className="error">{errors.description.message}</p>}
          </div>
        </section>

        {/* Submit */}
        {mutation.isError && (
          <div className="rounded-lg bg-red-50 border border-red-200 p-3 text-sm text-red-700">
            Failed to submit deal. Please try again.
          </div>
        )}
        <div className="flex items-center justify-between">
          <button type="button" onClick={() => router.back()} className="btn-secondary">
            Cancel
          </button>
          <button type="submit" disabled={isSubmitting || mutation.isPending} className="btn-primary">
            {mutation.isPending ? 'Submitting…' : 'Submit Deal Registration'}
          </button>
        </div>
      </form>
    </div>
  )
}
