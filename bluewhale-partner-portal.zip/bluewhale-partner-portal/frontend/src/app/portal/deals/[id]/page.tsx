'use client'

import { useQuery }             from '@tanstack/react-query'
import { useParams }            from 'next/navigation'
import { api }                  from '@/lib/api'
import { formatCurrency, DEAL_STATUS_LABEL, DEAL_STATUS_CLASS, TIER_LABEL } from '@/lib/utils'
import { format }               from 'date-fns'
import { WorkspaceMessages }    from '@/components/workspace/WorkspaceMessages'
import { WorkspaceTasks }       from '@/components/workspace/WorkspaceTasks'
import { WorkspaceMilestones }  from '@/components/workspace/WorkspaceMilestones'
import { DealAttachments }      from '@/components/deals/DealAttachments'
import { ArrowLeft, Calendar, DollarSign, Building2, Tag } from 'lucide-react'
import Link                     from 'next/link'
import type { Deal }            from '@/types'

export default function DealDetailPage() {
  const { id } = useParams<{ id: string }>()

  const { data: deal, isLoading } = useQuery<Deal>({
    queryKey: ['deal', id],
    queryFn:  () => api.get(`/deals/${id}`).then(r => r.data),
  })

  const { data: workspace } = useQuery({
    queryKey: ['workspace', id],
    queryFn:  () => api.get(`/workspace/${id}`).then(r => r.data),
    enabled:  !!id && ['ACCEPTED', 'IN_PROGRESS', 'WON', 'LOST'].includes(deal?.status ?? ''),
  })

  if (isLoading) {
    return (
      <div className="space-y-4 animate-pulse">
        <div className="h-8 w-64 rounded bg-gray-200" />
        <div className="h-48 rounded-xl bg-gray-100" />
      </div>
    )
  }

  if (!deal) return <p className="text-muted-foreground">Deal not found.</p>

  const hasWorkspace = ['ACCEPTED', 'IN_PROGRESS', 'WON', 'LOST'].includes(deal.status)

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Back + header */}
      <div>
        <Link
          href="/portal/deals"
          className="mb-3 flex items-center gap-1 text-xs text-muted-foreground hover:text-brand-700"
        >
          <ArrowLeft className="h-3 w-3" /> All Deals
        </Link>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold">{deal.dealName}</h1>
            <p className="text-sm text-muted-foreground font-mono">
              {deal.id.slice(0, 8).toUpperCase()}
            </p>
          </div>
          <span className={`rounded-full px-3 py-1 text-sm font-semibold ${DEAL_STATUS_CLASS[deal.status]}`}>
            {DEAL_STATUS_LABEL[deal.status]}
          </span>
        </div>
      </div>

      {/* Meta grid */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { icon: DollarSign, label: 'Deal Value',   value: formatCurrency(deal.estimatedValueUsd), color: 'text-emerald-600 bg-emerald-50' },
          { icon: Building2,  label: 'Prospect',     value: deal.prospectName,                      color: 'text-blue-600 bg-blue-50' },
          { icon: Calendar,   label: 'Close Date',   value: format(new Date(deal.expectedCloseDate), 'MMM d, yyyy'), color: 'text-purple-600 bg-purple-50' },
          { icon: Tag,        label: 'Products',     value: deal.products.join(', '),                color: 'text-amber-600 bg-amber-50' },
        ].map(m => {
          const Icon = m.icon
          return (
            <div key={m.label} className="stat-card flex items-start gap-3">
              <div className={`rounded-lg p-2 ${m.color}`}><Icon className="h-4 w-4" /></div>
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground">{m.label}</p>
                <p className="text-sm font-semibold truncate">{m.value}</p>
              </div>
            </div>
          )
        })}
      </div>

      {/* Deal info card */}
      <div className="stat-card space-y-4">
        <h2 className="text-sm font-semibold border-b pb-2">Deal Information</h2>
        <div className="grid grid-cols-1 gap-y-3 gap-x-8 sm:grid-cols-2 text-sm">
          {[
            ['Prospect Company',  deal.prospectName],
            ['Prospect Country',  deal.prospectCountry],
            ['Prospect Industry', deal.prospectIndustry],
            ['Contact Name',      deal.contactName],
            ['Contact Email',     deal.contactEmail],
            ['Contact Phone',     deal.contactPhone],
            ['Deal Source',       deal.dealSource],
            ['Incumbent',         deal.incumbent ?? '—'],
            ['Assigned AM',       deal.assignedAm?.name ?? 'Unassigned'],
            ['Submitted',         format(new Date(deal.createdAt), 'MMM d, yyyy')],
            ['Expires',           format(new Date(deal.expiryDate), 'MMM d, yyyy')],
          ].map(([label, value]) => (
            <div key={label}>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="font-medium text-gray-800 dark:text-gray-200">{value}</p>
            </div>
          ))}
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Description</p>
          <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">{deal.description}</p>
        </div>
      </div>

      {/* Attachments */}
      <DealAttachments dealId={id} attachments={deal.attachments} />

      {/* Workspace — only visible when deal is accepted+ */}
      {hasWorkspace ? (
        <div className="space-y-6">
          <h2 className="text-lg font-semibold">Co-sell Workspace</h2>
          <WorkspaceMilestones dealId={id} milestones={workspace?.milestones ?? []} />
          <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
            <WorkspaceMessages dealId={id} initialMessages={workspace?.messages ?? []} />
            <WorkspaceTasks    dealId={id} initialTasks={workspace?.tasks ?? []} />
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-dashed bg-gray-50 p-8 text-center dark:bg-gray-900">
          <p className="text-sm text-muted-foreground">
            The co-sell workspace opens once your deal is accepted by the BlueWhale Stack team.
          </p>
        </div>
      )}
    </div>
  )
}
