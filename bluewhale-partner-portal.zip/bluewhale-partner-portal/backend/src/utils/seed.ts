import 'dotenv/config'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // ── Internal Users ─────────────────────────────────────────────────────────
  const pm = await prisma.user.upsert({
    where:  { auth0Id: 'seed|pm1' },
    update: {},
    create: {
      auth0Id: 'seed|pm1',
      email:   'david.okafor@bluewhalestack.com',
      name:    'David Okafor',
      role:    'PARTNER_MANAGER',
    },
  })

  const am = await prisma.user.upsert({
    where:  { auth0Id: 'seed|am1' },
    update: {},
    create: {
      auth0Id: 'seed|am1',
      email:   'sarah.mitchell@bluewhalestack.com',
      name:    'Sarah Mitchell',
      role:    'ACCOUNT_MANAGER',
    },
  })

  const sales = await prisma.user.upsert({
    where:  { auth0Id: 'seed|sales1' },
    update: {},
    create: {
      auth0Id: 'seed|sales1',
      email:   'james.ruiz@bluewhalestack.com',
      name:    'James Ruiz',
      role:    'SALES_REP',
    },
  })

  const finance = await prisma.user.upsert({
    where:  { auth0Id: 'seed|finance1' },
    update: {},
    create: {
      auth0Id: 'seed|finance1',
      email:   'lin.wei@bluewhalestack.com',
      name:    'Lin Wei',
      role:    'FINANCE_APPROVER',
    },
  })

  const admin = await prisma.user.upsert({
    where:  { auth0Id: 'seed|admin1' },
    update: {},
    create: {
      auth0Id: 'seed|admin1',
      email:   'admin@bluewhalestack.com',
      name:    'Portal Admin',
      role:    'PORTAL_ADMIN',
    },
  })

  // ── Partner 1 — TechBridge (Gold) ──────────────────────────────────────────
  const partner1 = await prisma.partner.upsert({
    where:  { registrationNumber: 'TB-2021-UK' },
    update: {},
    create: {
      companyName:        'TechBridge Solutions',
      registrationNumber: 'TB-2021-UK',
      countryCode:        'GB',
      website:            'https://techbridge.io',
      industry:           'Technology',
      tier:               'GOLD',
      status:             'ACTIVE',
      assignedPmId:       pm.id,
      annualRevenue:      420000,
      tierReviewDate:     new Date('2026-01-01'),
    },
  })

  const partner1Admin = await prisma.user.upsert({
    where:  { auth0Id: 'seed|p1admin' },
    update: {},
    create: {
      auth0Id:   'seed|p1admin',
      email:     'alex.chen@techbridge.io',
      name:      'Alex Chen',
      role:      'PARTNER_ADMIN',
      partnerId: partner1.id,
    },
  })

  await prisma.user.upsert({
    where:  { auth0Id: 'seed|p1user' },
    update: {},
    create: {
      auth0Id:   'seed|p1user',
      email:     'priya.sharma@techbridge.io',
      name:      'Priya Sharma',
      role:      'PARTNER_USER',
      partnerId: partner1.id,
    },
  })

  // ── Partner 2 — CloudVault (Silver) ────────────────────────────────────────
  const partner2 = await prisma.partner.upsert({
    where:  { registrationNumber: 'CV-2022-US' },
    update: {},
    create: {
      companyName:        'CloudVault Inc',
      registrationNumber: 'CV-2022-US',
      countryCode:        'US',
      website:            'https://cloudvault.com',
      industry:           'Finance',
      tier:               'SILVER',
      status:             'ACTIVE',
      assignedPmId:       pm.id,
      annualRevenue:      95000,
      tierReviewDate:     new Date('2026-03-01'),
    },
  })

  await prisma.user.upsert({
    where:  { auth0Id: 'seed|p2admin' },
    update: {},
    create: {
      auth0Id:   'seed|p2admin',
      email:     'admin@cloudvault.com',
      name:      'Michael Torres',
      role:      'PARTNER_ADMIN',
      partnerId: partner2.id,
    },
  })

  // ── Deal 1 — Active in-progress deal ────────────────────────────────────────
  const deal1 = await prisma.deal.upsert({
    where:  { id: 'seed-deal-001' },
    update: {},
    create: {
      id:                'seed-deal-001',
      dealName:          'Acme Corp – BW Cloud Platform',
      partnerId:         partner1.id,
      prospectName:      'Acme Corporation',
      prospectWebsite:   'https://acme.com',
      prospectCountry:   'United States',
      prospectIndustry:  'Manufacturing',
      contactName:       'Sandra Lee',
      contactEmail:      'sandra.lee@acme.com',
      contactPhone:      '+1 415 555 0100',
      products:          ['BW Cloud Platform', 'BW Security Hub'],
      estimatedValueUsd: 380000,
      status:            'IN_PROGRESS',
      dealSource:        'Outbound Prospecting',
      description:       'Acme Corp is looking to migrate their legacy on-prem infrastructure to cloud. They evaluated 3 vendors. BlueWhale Stack is the preferred vendor based on our security capabilities and enterprise SLA commitments. The deal is in final commercial negotiation stage.',
      expectedCloseDate: new Date('2025-09-30'),
      expiryDate:        new Date('2025-10-01'),
      assignedAmId:      am.id,
      milestones: {
        create: [
          { label: 'Discovery',            order: 1, completedAt: new Date('2025-05-01'), completedById: am.id },
          { label: 'Technical Validation', order: 2, completedAt: new Date('2025-06-15'), completedById: am.id },
          { label: 'Proposal Submitted',   order: 3, completedAt: new Date('2025-07-20'), completedById: am.id },
          { label: 'Legal / Commercial',   order: 4 },
          { label: 'PO Received',          order: 5 },
        ],
      },
    },
  })

  // Workspace messages for deal 1
  await prisma.workspaceMessage.createMany({
    skipDuplicates: true,
    data: [
      {
        dealId:     deal1.id,
        authorId:   am.id,
        content:    'Hi Priya, I\'ve reviewed the deal and I\'m ready to jump in. Can we schedule a discovery call with Sandra at Acme for next week?',
        isInternal: false,
        createdAt:  new Date('2025-05-01T09:00:00'),
      },
      {
        dealId:     deal1.id,
        authorId:   partner1Admin.id,
        content:    'Great! Sandra is available Tuesday or Thursday afternoon EST. I\'ll confirm the slot and send you a calendar invite.',
        isInternal: false,
        createdAt:  new Date('2025-05-01T10:30:00'),
      },
      {
        dealId:     deal1.id,
        authorId:   am.id,
        content:    'Internal note: Acme is also evaluating AWS Direct Connect for their networking layer. We need to position our hybrid cloud story stronger in the proposal.',
        isInternal: true,
        createdAt:  new Date('2025-05-10T14:00:00'),
      },
    ],
  })

  // Deal 1 tasks
  await prisma.workspaceTask.createMany({
    skipDuplicates: true,
    data: [
      {
        dealId:      deal1.id,
        title:       'Submit final commercial proposal',
        assigneeId:  partner1Admin.id,
        createdById: am.id,
        dueDate:     new Date('2025-08-15'),
        priority:    'HIGH',
        status:      'IN_PROGRESS',
      },
      {
        dealId:      deal1.id,
        title:       'Legal review of MSA terms',
        assigneeId:  am.id,
        createdById: am.id,
        dueDate:     new Date('2025-08-20'),
        priority:    'HIGH',
        status:      'OPEN',
      },
      {
        dealId:      deal1.id,
        title:       'Security questionnaire response',
        assigneeId:  partner1Admin.id,
        createdById: am.id,
        dueDate:     new Date('2025-08-10'),
        priority:    'MEDIUM',
        status:      'COMPLETED',
        completedAt: new Date('2025-08-08'),
      },
    ],
  })

  // Deal 1 discount
  await prisma.discount.create({
    data: {
      dealId:        deal1.id,
      partnerId:     partner1.id,
      product:       'BW Cloud Platform',
      listPriceUsd:  380000,
      requestedPct:  25,
      approvedPct:   25,
      status:        'APPROVED',
      justification: 'Competitive displacement deal. Acme Corp is currently on a competitor contract expiring Q3 2025. To win this deal we need to offer a competitive first-year price.',
      approvedById:  am.id,
      approvedAt:    new Date('2025-07-25'),
    },
  })

  // ── Deal 2 — Submitted pending review ───────────────────────────────────────
  await prisma.deal.upsert({
    where:  { id: 'seed-deal-002' },
    update: {},
    create: {
      id:                'seed-deal-002',
      dealName:          'FinanceFlow Corp – BW Data Suite',
      partnerId:         partner2.id,
      prospectName:      'FinanceFlow Corp',
      prospectCountry:   'United States',
      prospectIndustry:  'Finance',
      contactName:       'Robert Kim',
      contactEmail:      'r.kim@financeflow.com',
      contactPhone:      '+1 212 555 0200',
      products:          ['BW Data Suite', 'BW Analytics Pro'],
      estimatedValueUsd: 145000,
      status:            'SUBMITTED',
      dealSource:        'Inbound Referral',
      description:       'FinanceFlow Corp requires a real-time data analytics platform to comply with new SEC reporting requirements coming into effect Q1 2026. They have a hard deadline and are evaluating 2 vendors. BW Data Suite is the strongest fit based on their compliance requirement matrix.',
      expectedCloseDate: new Date('2025-10-15'),
      expiryDate:        new Date('2025-11-01'),
      assignedAmId:      null,
      milestones: {
        create: [
          { label: 'Discovery',            order: 1 },
          { label: 'Technical Validation', order: 2 },
          { label: 'Proposal Submitted',   order: 3 },
          { label: 'Legal / Commercial',   order: 4 },
          { label: 'PO Received',          order: 5 },
        ],
      },
    },
  })

  // ── Status history ─────────────────────────────────────────────────────────
  await prisma.dealStatusHistory.createMany({
    skipDuplicates: true,
    data: [
      { dealId: deal1.id, toStatus: 'SUBMITTED',   changedById: partner1Admin.id, createdAt: new Date('2025-04-28') },
      { dealId: deal1.id, fromStatus: 'SUBMITTED',   toStatus: 'UNDER_REVIEW', changedById: sales.id, createdAt: new Date('2025-04-29') },
      { dealId: deal1.id, fromStatus: 'UNDER_REVIEW', toStatus: 'ACCEPTED',    changedById: sales.id, createdAt: new Date('2025-04-30') },
      { dealId: deal1.id, fromStatus: 'ACCEPTED',    toStatus: 'IN_PROGRESS',  changedById: am.id,    createdAt: new Date('2025-05-01') },
    ],
  })

  console.log('✅ Seed complete!')
  console.log(`   Partners: TechBridge (Gold), CloudVault (Silver)`)
  console.log(`   Internal users: PM, AM, Sales Rep, Finance, Admin`)
  console.log(`   Deals: 2 (1 in-progress, 1 submitted)`)
  console.log(`   Messages, tasks, milestones, discount seeded for Deal 1`)
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
