import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
  GetObjectCommand,
} from '@aws-sdk/client-s3'
import { getSignedUrl }  from '@aws-sdk/s3-request-presigner'
import { randomUUID }    from 'crypto'
import path              from 'path'

const s3 = new S3Client({
  region:      process.env.AWS_REGION ?? 'us-east-1',
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID ?? '',
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? '',
  },
})

const BUCKET = process.env.S3_BUCKET_NAME ?? 'bw-partner-portal-files'

export const S3Service = {

  async uploadFile(opts: {
    buffer:    Buffer
    mimeType:  string
    fileName:  string
    folder:    string
  }) {
    const ext      = path.extname(opts.fileName)
    const key      = `${opts.folder}/${randomUUID()}${ext}`

    await s3.send(new PutObjectCommand({
      Bucket:      BUCKET,
      Key:         key,
      Body:        opts.buffer,
      ContentType: opts.mimeType,
      ServerSideEncryption: 'AES256',
    }))

    return {
      key,
      url: `https://${BUCKET}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`,
    }
  },

  async deleteFile(key: string) {
    await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }))
  },

  async getPresignedDownloadUrl(key: string, expiresInSeconds = 3600) {
    return getSignedUrl(
      s3,
      new GetObjectCommand({ Bucket: BUCKET, Key: key }),
      { expiresIn: expiresInSeconds }
    )
  },

  async getPresignedUploadUrl(opts: {
    folder:   string
    fileName: string
    mimeType: string
    maxBytes?: number
  }) {
    const ext = path.extname(opts.fileName)
    const key = `${opts.folder}/${randomUUID()}${ext}`

    // Note: presigned PUT uploads are done client-side directly to S3
    const url = await getSignedUrl(
      s3,
      new PutObjectCommand({
        Bucket:      BUCKET,
        Key:         key,
        ContentType: opts.mimeType,
      }),
      { expiresIn: 600 } // 10 minutes
    )

    return { url, key }
  },
}
