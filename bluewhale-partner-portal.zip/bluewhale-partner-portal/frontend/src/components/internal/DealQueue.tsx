'use client'

import { useState }           from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import Link                   from 'next/link'
import { api }                from '@/lib/api'
import { formatCurrency, DEAL_STATUS_LABEL, DEAL_STATUS_CLASS } from '@/lib/utils'
import { formatDistanceToNow } from 'date-fns'
import { CheckCircle, XCircle, Eye } from 'lucide-react'
import type { Deal }          from '@/types'

export function DealQueue() {
  const queryClient = useQueryClient()
  const [rejectId, setRejectId]     = useState<string | null>(null)
  const [rejectReason, setRejectReason] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['internal-deals', 'submitted'],
    queryFn:  () => api.get('/deals', { params: { status: 'SUBMITTED', pageSize: 10 } }).then(r => r.data),
    refetchInterval: 30_000,
  })

  const acceptMutation = useMutation({
    mutationFn: (dealId: string) =>
      api.patch(`/deals/${dealId}/status`, { status: 'ACCEPTED' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['internal-deals'] }),
  })

  const rejectMutation = useMutation({
    mutationFn: ({ dealId, reason }: { dealId: string; reason: string }) =>
      api.patch(`/deals/${dealId}/status`, { status: 'REJECTED', reason }),
    onSuccess: () => {
      setRejectId(null)
      setRejectReason('')
      queryClient.invalidateQueries({ queryKey: ['internal-deals'] })
    },
  })

  const deals: Deal[] = data?.data ?? []

  return (
    <div className="stat-card">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Deal Registration Queue</h3>
          <p className="text-xs text-muted-foreground">Submitted deals awaiting review — 72hr SLA</p>
        </div>
        <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-700">
          {data?.total ?? 0} pending
        </span>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-16 animate-pulse rounded-lg bg-gray-100" />
          ))}
        </div>
      ) : deals.length === 0 ? (
        <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
          No pending deals — queue is clear
        </div>
      ) : (
        <div className="space-y-2">
          {deals.map(deal => (
            <div key={deal.id} className="flex items-center gap-3 rounded-lg border p-3 hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <Link
                    href={`/internal/deals/${deal.id}`}
                    className="text-sm font-medium text-brand-700 hover:underline truncate"
                  >
                    {deal.dealName}
                  </Link>
                  <span className={`flex-shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium ${DEAL_STATUS_CLASS[deal.status]}`}>
                    {DEAL_STATUS_LABEL[deal.status]}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                  <span>{deal.prospectName}</span>
                  <span>·</span>
                  <span className="font-medium text-gray-700">{formatCurrency(deal.estimatedValueUsd)}</span>
                  <span>·</span>
                  <span>{formatDistanceToNow(new Date(deal.createdAt), { addSuffix: true })}</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 flex-shrink-0">
                <Link
                  href={`/internal/deals/${deal.id}`}
                  className="rounded p-1.5 text-muted-foreground hover:bg-gray-100"
                  title="View deal"
                >
                  <Eye className="h-3.5 w-3.5" />
                </Link>
                <button
                  onClick={() => acceptMutation.mutate(deal.id)}
                  disabled={acceptMutation.isPending}
                  className="rounded p-1.5 text-emerald-600 hover:bg-emerald-50"
                  title="Accept deal"
                >
                  <CheckCircle className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => setRejectId(deal.id)}
                  className="rounded p-1.5 text-red-500 hover:bg-red-50"
                  title="Reject deal"
                >
                  <XCircle className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Reject modal */}
      {rejectId && (
        <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-4 space-y-3">
          <p className="text-sm font-medium text-red-700">Rejection reason (required)</p>
          <textarea
            value={rejectReason}
            onChange={e => setRejectReason(e.target.value)}
            rows={3}
            className="w-full rounded border border-red-200 bg-white px-3 py-2 text-sm outline-none focus:border-red-400"
            placeholder="Duplicate prospect, outside territory, insufficient information..."
          />
          <div className="flex gap-2 justify-end">
            <button
              onClick={() => { setRejectId(null); setRejectReason('') }}
              className="px-3 py-1.5 text-xs border rounded hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={() => rejectMutation.mutate({ dealId: rejectId, reason: rejectReason })}
              disabled={!rejectReason.trim() || rejectMutation.isPending}
              className="px-3 py-1.5 text-xs bg-red-600 text-white rounded hover:bg-red-700 disabled:opacity-50"
            >
              Confirm Reject
            </button>
          </div>
        </div>
      )}

      <div className="mt-4 pt-3 border-t">
        <Link href="/internal/deals" className="text-xs text-brand-700 hover:underline">
          View all deals →
        </Link>
      </div>
    </div>
  )
}
