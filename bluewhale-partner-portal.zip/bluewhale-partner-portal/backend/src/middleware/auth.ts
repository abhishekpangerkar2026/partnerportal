import fp from 'fastify-plugin'
import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify'
import jwksClient from 'jwks-rsa'
import jwt from 'jsonwebtoken'
import { prisma } from '../config/db'
import type { UserRole } from '@prisma/client'

const client = jwksClient({
  jwksUri: `https://${process.env.AUTH0_DOMAIN}/.well-known/jwks.json`,
  cache: true,
  cacheMaxAge: 600_000, // 10 minutes
})

function getSigningKey(kid: string): Promise<string> {
  return new Promise((resolve, reject) => {
    client.getSigningKey(kid, (err, key) => {
      if (err) return reject(err)
      resolve(key!.getPublicKey())
    })
  })
}

export interface JwtUser {
  sub:   string   // Auth0 user ID
  email: string
  role:  UserRole
  partnerId?: string
  dbId:  string   // internal postgres user id
}

declare module 'fastify' {
  interface FastifyRequest {
    jwtUser?: JwtUser
  }
}

export const authPlugin = fp(async (fastify: FastifyInstance) => {
  fastify.decorate('authenticate', authenticate)
  fastify.decorate('requireRoles', requireRoles)
})

export async function authenticate(req: FastifyRequest, reply: FastifyReply) {
  const authHeader = req.headers.authorization
  if (!authHeader?.startsWith('Bearer ')) {
    return reply.code(401).send({ error: 'Unauthorized', message: 'Missing bearer token' })
  }

  const token = authHeader.slice(7)

  try {
    const decoded = jwt.decode(token, { complete: true })
    if (!decoded || typeof decoded === 'string') throw new Error('Invalid token')

    const kid   = decoded.header.kid!
    const pubKey = await getSigningKey(kid)

    const payload = jwt.verify(token, pubKey, {
      algorithms: ['RS256'],
      audience:   process.env.AUTH0_AUDIENCE,
      issuer:     `https://${process.env.AUTH0_DOMAIN}/`,
    }) as jwt.JwtPayload

    // Load user from DB (creates on first login)
    let dbUser = await prisma.user.findUnique({ where: { auth0Id: payload.sub! } })
    if (!dbUser) {
      return reply.code(401).send({ error: 'Unauthorized', message: 'User not provisioned' })
    }

    req.jwtUser = {
      sub:       payload.sub!,
      email:     dbUser.email,
      role:      dbUser.role,
      partnerId: dbUser.partnerId ?? undefined,
      dbId:      dbUser.id,
    }
  } catch (err) {
    return reply.code(401).send({ error: 'Unauthorized', message: 'Invalid or expired token' })
  }
}

export function requireRoles(roles: UserRole[]) {
  return async (req: FastifyRequest, reply: FastifyReply) => {
    await authenticate(req, reply)
    if (!req.jwtUser || !roles.includes(req.jwtUser.role)) {
      return reply.code(403).send({ error: 'Forbidden', message: 'Insufficient permissions' })
    }
  }
}
