import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User, Partner } from '@/types'

interface AppState {
  user:        User | null
  partner:     Partner | null
  setUser:     (user: User | null) => void
  setPartner:  (partner: Partner | null) => void
  clearAll:    () => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      user:       null,
      partner:    null,
      setUser:    (user)    => set({ user }),
      setPartner: (partner) => set({ partner }),
      clearAll:   ()        => set({ user: null, partner: null }),
    }),
    { name: 'bw-partner-store' }
  )
)
